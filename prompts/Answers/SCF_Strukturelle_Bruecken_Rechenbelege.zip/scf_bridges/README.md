# Rechenbelege zum Konzept struktureller Brücken

Erstellt am 20. September 2026 für GenesisAeon/scoped-correspondence-formalism.
Bezugsstand: 17edd7b26816d2b67f42826be600371f94c7e320.

## Inhalt

- `verify_structural_bridges.py`: sieben kleine mathematische Rechengruppen.
- `bridge_results.json`: tatsächlich erzeugte Ergebnisse, Umgebung und Git-Blob-Fingerabdrücke der verwendeten acht Quelldateien.
- `source_commit.json`: Metadaten zum betrachteten Commit und den dort veränderten Dateien.

Die Herleitungen, Beziehungstypen, Grenzen und Quellen stehen im separat
bereitgestellten Dokument `SCF_Strukturelle_Bruecken_Konzept.md`.

## Reproduktion

Benötigt werden der oben genannte Repository-Stand sowie Python, NumPy und SciPy.
Ausgeführt mit Python 3.12.14, NumPy 2.3.5 und SciPy 1.17.0.

```bash
python verify_structural_bridges.py --repo /pfad/zum/scoped-correspondence-formalism --output neue_ergebnisse.json
```

Das Skript liest die vorhandenen Module und verändert das Repository nicht.
Es führt keine Netzwerkanfragen aus. Bei einer verletzten Erwartung endet es
mit einem AssertionError; bei Erfolg enthält die JSON-Ausgabe sieben Gruppen.
Das Skript prüft endliche Modellfälle. Die allgemeinen algebraischen Aussagen
werden im Konzept hergeleitet; numerische Ergebnisse ersetzen diese Begründungen nicht.

Die acht importierten Quelldateien sind im betrachteten Commit gegenüber
3bb7d601f3aa57ca09f72cd5c85c3d97e9ca4b19 unverändert. Ihre Git-Blob-SHAs wurden
mit dem zuvor vollständig erfassten GitHub-Baum abgeglichen: acht von acht stimmen.
Der neuere Commit ändert Audittexte und Linkprüfungen, keine dieser Module.

Es wurden weder ein produktiver Brückenvertrag noch neue Repository-Module
implementiert. Die Dateien sind überprüfbare Konzeptbelege für eine spätere Integration.
