"""Seven reproducible mathematical examples for the SCF bridge proposal.

Usage: python verify_structural_bridges.py --repo /path/to/scoped-correspondence-formalism
Requires Python 3.10+, NumPy and SciPy. Does not modify the repository.
Analytic arguments are in the accompanying concept document; numerical checks
are finite examples, not universal proofs. No network or empirical data needed.
"""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
import platform
import sys
from pathlib import Path

import numpy as np
import scipy
from scipy.linalg import expm

parser = argparse.ArgumentParser()
parser.add_argument('--repo', type=Path, required=True)
parser.add_argument('--output', type=Path, default=Path('bridge_results.json'))
args = parser.parse_args()
sys.path.insert(0, str(args.repo.resolve() / 'src'))

from scoped_correspondence.membership.core import MembershipMatrix
from scoped_correspondence.membership.formal_concept_analysis import derive_up, derive_down
from scoped_correspondence.chemical_organization.core import is_reaction_closed, is_organization
from scoped_correspondence.closure.generator_lumpability import is_exact_generator_lumpability
from scoped_correspondence.thermo.schnakenberg import entropy_production_rate
from scoped_correspondence.coupling.generalized_sync import linear_drive_response_map
from scoped_correspondence.dynamics.core import recovery_rate_at_equilibrium
from scoped_correspondence.pattern_formation.core import dispersion_relation

results = {}

def close(a, b, tol=1e-12):
    aa, bb = np.asarray(a), np.asarray(b)
    assert np.isfinite(aa).all() and np.isfinite(bb).all()
    assert np.allclose(aa, bb, atol=tol, rtol=0), (a, b)

def powerset(items):
    items = tuple(items)
    return [frozenset(s) for n in range(len(items)+1) for s in itertools.combinations(items, n)]

# B1: reaction closure represented by an explicitly constructed FCA context.
U = frozenset(range(3))
reactions = [(frozenset([0]), frozenset([1])), (frozenset([1]), frozenset([2]))]
subsets = powerset(sorted(U))
def reaction_hull(A):
    A = frozenset(A)
    while True:
        next_A = A | frozenset().union(*(p for r, p in reactions if r <= A))
        if next_A == A:
            return A
        A = next_A

closed_sets = [A for A in subsets if is_reaction_closed(A, reactions)]
context = MembershipMatrix(np.array([[int(i in A) for A in closed_sets] for i in sorted(U)]))
for A in subsets:
    assert derive_down(derive_up(A, context), context) == reaction_hull(A)
    assert A <= reaction_hull(A)
    assert reaction_hull(reaction_hull(A)) == reaction_hull(A)
    for B in subsets:
        if A <= B:
            assert reaction_hull(A) <= reaction_hull(B)
arbitrary_context = MembershipMatrix(np.eye(3))
assert derive_down(derive_up({0}, arbitrary_context), arbitrary_context) != reaction_hull({0})
results['B1_reaction_FCA'] = {
    'status': 'pass', 'subsets_checked': len(subsets),
    'closed_sets': [sorted(A) for A in closed_sets],
    'constructed_context': context.matrix.astype(int).tolist(),
    'arbitrary_context_counterexample': True,
}

# B2: distribution aggregation and observable lifting use the same equation.
P = np.array([[.4, .3, .2, .1], [.1, .6, .15, .15],
              [.2, .2, .3, .3], [.3, .1, .1, .5]])
C = np.array([[1, 0], [1, 0], [0, 1], [0, 1]])
Q = np.array([[.7, .3], [.4, .6]])
close(P.sum(axis=1), np.ones(4)); close(Q.sum(axis=1), np.ones(2))
assert (P >= 0).all() and (Q >= 0).all()
close(P @ C, C @ Q)
for n in [0, 1, 2, 5, 10]:
    close(np.linalg.matrix_power(P, n) @ C, C @ np.linalg.matrix_power(Q, n))
for g in np.eye(2):
    close(P @ (C @ g), C @ (Q @ g))
P_bad = P.copy(); P_bad[0, 0] -= .05; P_bad[0, 2] += .05
assert not np.allclose((P_bad @ C)[0], (P_bad @ C)[1])
results['B2_operator_intertwining'] = {
    'status': 'pass', 'P': P.tolist(), 'C': C.tolist(), 'Q': Q.tolist(),
    'residual_max': float(np.abs(P @ C - C @ Q).max()),
    'powers_checked': [0, 1, 2, 5, 10],
    'nonlumpable_row_difference': ((P_bad @ C)[0] - (P_bad @ C)[1]).tolist(),
}

# B3: scalar conditional exponent matches contraction; nonnormal case needs a metric.
sync = linear_drive_response_map(4, 3)
close(sync.phi, 2); close(sync.cle, -3)
# y'=-3y+4x, x'=-x, e=y-2x => e'=-3e.
A = np.array([[-1., 4.], [0., -1.]])
H = np.array([[.5, 1.], [1., 4.5]])
close(A.T @ H + H @ A, -np.eye(2))
assert np.linalg.eigvalsh(H).min() > 0
sym_max = float(np.linalg.eigvalsh((A + A.T)/2).max())
growth = float(np.linalg.norm(expm(A) @ np.array([0., 1.])))
assert sym_max > 0 and growth > 1
close(growth, math.sqrt(17)/math.e)
results['B3_sync_contraction'] = {
    'status': 'pass', 'scalar_phi': sync.phi, 'scalar_CLE': sync.cle,
    'A': A.tolist(), 'metric_H': H.tolist(),
    'spectral_abscissa': float(np.linalg.eigvals(A).real.max()),
    'euclidean_symmetric_part_max': sym_max,
    'euclidean_norm_at_t1_from_unit_vector': growth,
    'lyapunov_identity_residual': float(np.abs(A.T @ H + H @ A + np.eye(2)).max()),
}

# B4: exact nontrivial macro dynamics hides stationary cyclic dissipation.
G = np.zeros((6, 6))
for offset in [0, 3]:
    for i in range(3):
        G[offset+i, offset+(i+1)%3] = 2.
        G[offset+i, offset+(i-1)%3] = 1.
for i in range(3):
    G[i, i+3] = G[i+3, i] = 1.
np.fill_diagonal(G, -G.sum(axis=1))
C6 = np.array([[1, 0]]*3 + [[0, 1]]*3)
Gbar = np.array([[-1., 1.], [1., -1.]])
pi = np.ones(6)/6; pibar = pi @ C6
close(pi @ G, np.zeros(6)); close(pibar @ Gbar, np.zeros(2))
close(G @ C6, C6 @ Gbar)
assert is_exact_generator_lumpability(G, C6, Gbar)
sigma_micro = entropy_production_rate(pi, G)
sigma_macro = entropy_production_rate(pibar, Gbar)
close(sigma_micro, math.log(2)); close(sigma_macro, 0)
for t in [0, .1, 1, 2]:
    close(expm(t*G) @ C6, C6 @ expm(t*Gbar))
results['B4_hidden_entropy'] = {
    'status': 'pass', 'generator': G.tolist(), 'C': C6.tolist(),
    'macro_generator': Gbar.tolist(), 'stationary_pi': pi.tolist(),
    'sigma_micro': sigma_micro, 'sigma_macro': sigma_macro,
    'units': 'natural logarithm, k_B=1, rates per chosen time unit',
    'generator_intertwining_residual': float(np.abs(G @ C6 - C6 @ Gbar).max()),
    'semigroup_times_checked': [0, .1, 1, 2],
}

# B5: same spectral functional, without a conjugacy between different models.
J = np.array([[-2., 0.], [0., -5.]])
d0 = dispersion_relation(J, 1, 2, 0)
close(d0.re_lambda_max, -2.)
close(recovery_rate_at_equilibrium(1, 1, 1), 2.)
# Scalar cubic at x*=1 has derivative -2; embedded second mode has derivative -5.
# Numeric agreement is deliberately not used as evidence of full-system equivalence.
for k in [0, .25, 1, 2]:
    d = dispersion_relation(J, 1, 2, k)
    close(d.re_lambda_max, np.linalg.eigvals(J-k*k*np.diag([1,2])).real.max())
results['B5_linearization'] = {
    'status': 'pass', 'J': J.tolist(), 'spectral_recovery_at_k0': -d0.re_lambda_max,
    'scalar_cubic_recovery': recovery_rate_at_equilibrium(1, 1, 1),
    'wave_numbers_checked': [0, .25, 1, 2],
    'claim': 'same spectral functional in a specified linearization; no conjugacy claimed',
}

# B6: m=2 branching has an exact survival formula, distinct from cubic exponent 1/2.
deltas = [1e-2, 1e-3, 1e-4, 1e-5]
branch_values = []
for delta in deltas:
    p = .5 + delta
    theta = (2*p - 1)/(p*p)
    q = 1-theta
    close(q, (1-p+p*q)**2)
    branch_values.append({'delta': delta, 'theta': theta, 'theta_over_delta': theta/delta})
assert abs(branch_values[-1]['theta_over_delta'] - 8) < .001
cubic_slope = math.log(math.sqrt(1e-6)/math.sqrt(1e-4))/math.log(1e-6/1e-4)
close(cubic_slope, .5)
results['B6_branching_normal_form'] = {
    'status': 'pass', 'm': 2, 'critical_p': .5, 'samples': branch_values,
    'analytic_branching_exponent': 1, 'analytic_cubic_exponent': .5,
    'claim': 'local equilibrium-equation comparison, not physical-time conjugacy',
}

# B7: stoichiometric organization does not imply a finite positive equilibrium.
# A -> 2 A is an open autocatalytic birth model (an external resource is implicit).
organization = is_organization({'A'}, [({'A'}, {'A'})], [[1]], species_order=['A'])
assert organization
for x in [.1, 1, 10]:
    assert 2*x > 0  # mass-action x'=2x has no positive finite fixed point.
results['B7_organization_not_equilibrium'] = {
    'status': 'pass', 'reaction': 'A -> 2 A', 'stoichiometric_coefficient': 1,
    'is_organization': bool(organization),
    'analytic_kinetics': 'dx/dt = k*x > 0 for k>0 and x>0',
    'scope': 'open birth model; not a closed mass-conserving chemistry',
}

source_files = [
    'membership/core.py', 'membership/formal_concept_analysis.py',
    'chemical_organization/core.py', 'closure/generator_lumpability.py',
    'thermo/schnakenberg.py', 'coupling/generalized_sync.py',
    'dynamics/core.py', 'pattern_formation/core.py',
]
fingerprints = {}
for name in source_files:
    data = (args.repo / 'src/scoped_correspondence' / name).read_bytes()
    fingerprints[name] = hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
output = {
    'target_commit': '17edd7b26816d2b67f42826be600371f94c7e320',
    'source_note': 'Imported source files unchanged from parent 3bb7d601f; commit only changed audit/docs/link checks.',
    'environment': {'python': platform.python_version(), 'numpy': np.__version__, 'scipy': scipy.__version__},
    'source_git_blob_sha1': fingerprints,
    'verification_type': 'seven finite mathematical demonstrations; analytic arguments in companion document',
    'results': results,
    'summary': {'groups': len(results), 'passed': len(results)},
}
args.output.write_text(json.dumps(output, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps(output, ensure_ascii=False, indent=2))
