"""Counterchecks for SCF 3e8dce3. Read-only use of repository; outputs stay here."""
from pathlib import Path
import json,sys,math,dataclasses
from unittest.mock import patch
import numpy as np
ROOT=Path(__file__).resolve().parent;REPO=ROOT/'repo';sys.path.insert(0,str(REPO/'src'))
from scoped_correspondence.validation.rolling_origin import RawHorizonPrediction
from scoped_correspondence.validation.mechanistic_probabilistic_evaluation import leave_one_origin_out_intervals
from scoped_correspondence.validation import covid_observation_model as om
from scoped_correspondence.validation.covid_pilot import load_world_daily
from scoped_correspondence.identifiability.profile_likelihood import likelihood_interval
from scoped_correspondence.validation.covid_renewal import discretized_generation_interval
OUT={'commit':'3e8dce358e37017b375aaaae5b6f0bfe63f4d94f'}
# Historical interval changes when only a later origin's outcome changes.
raw=[RawHorizonPrediction(float(o),1,float(o),0.) for o in range(4)]
a=leave_one_origin_out_intervals({'example':raw})['example'].per_trial[0]
raw[-1]=dataclasses.replace(raw[-1],observed=100.)
b=leave_one_origin_out_intervals({'example':raw})['example'].per_trial[0]
OUT['future_information_in_interval']={'original_origin0':a,'after_only_origin3_observation_changed':b,'same_origin0_prediction':True,'interval_changed':a['upper']!=b['upper']}
# Same-date observed raw count participates in the claimed predicted mean.
path=REPO/'data/owid_covid_world_daily_2020_2023.csv';points=load_world_daily(path)
target='2020-03-12';j=next(i for i,p in enumerate(points) if p.date.isoformat()==target)
p=points[j];same_week=[q.new_cases for q in points[j-6:j+1]]
base=om.run_covid_observation_model_comparison(path)
changed=[]
for i,q in enumerate(points):
 changes={}
 if i==j:changes['new_cases']=q.new_cases+700
 if j<=i<=j+6:changes.update(weekly_cases=q.weekly_cases+700,cases_7day_avg=q.cases_7day_avg+100)
 changed.append(dataclasses.replace(q,**changes) if changes else q)
with patch.object(om,'load_world_daily',return_value=changed):alt=om.run_covid_observation_model_comparison(path)
a=next(x for x in base.per_holdout_day if x['date']==target);b=next(x for x in alt.per_holdout_day if x['date']==target)
OUT['target_information_in_covid_mean']={'target_date':target,'actual_7_day_sum_over_7':sum(same_week)/7,'reported_cases_7day_avg':p.cases_7day_avg,'original':a,'after_only_target_and_derived_weekly_aggregates_changed':b,'same_fitted_dispersion':base.fitted_dispersion==alt.fitted_dispersion,'unchanged_past_raw_observations':True}
# A finite unresolved scan cannot establish an unbounded confidence set.
profile=[(float(x),float(x*x)) for x in [-.5,0,.5]]
OUT['finite_profile_scan']={'profile':profile,'repo_report':likelihood_interval(profile,1.0),'known_global_interval':[-1.,1.],'model':'chi2(theta)=theta^2'}
# Time-homogeneous offspring kernel does not imply stationarity of the process.
w=discretized_generation_interval();R=1.68;mu=1.
OUT['branching_stationarity']={'R':R,'kernel_mass':float(R*w.sum()),'stationary_mean_equation_candidate':mu/(1-R),'impossible_negative_mean':mu/(1-R)<0,'partial_sum_expected_generations_0_to_20':sum(R**k for k in range(21)),'subcritical_comparison':{'R':.8,'mu':1.,'stationary_mean':1/(1-.8)}}
(ROOT/'independent_results.json').write_text(json.dumps(OUT,indent=2)+'\n')
for name,detail in OUT.items():print(name,json.dumps(detail),flush=True)
