"""Sensitivity to forcing reference level; not a new climate attribution analysis."""
from pathlib import Path
import sys,json
import numpy as np
ROOT=Path(__file__).resolve().parent;REPO=ROOT/'repo';sys.path.insert(0,str(REPO/'src'))
from scoped_correspondence.dynamics.energy_balance import _load_overlap_series,fit_energy_balance_model_from_series
from scoped_correspondence.validation.energy_balance_full_forcing import load_erf_series
y,T,Fmy=_load_overlap_series(REPO/'data/noaa_mauna_loa_co2_annual_1959_2025.txt',REPO/'data/noaa_global_temp_anomaly_1880_2025.csv')
erf=load_erf_series(REPO/'data/climateindicator_erf_best_aggregates_1750_2025.csv');Fc=np.array([erf[a]['CO2'] for a in y]);Ft=np.array([erf[a]['total'] for a in y])
report={'first_year':y[0],'first_forcings':{'myhre_co2':float(Fmy[0]),'erf_co2':float(Fc[0]),'erf_total':float(Ft[0])},'runs':{}}
for name,F in [('erf_co2_minus_1959',Fc-Fc[0]),('erf_total_minus_1959',Ft-Ft[0]),('myhre_plus_erf1959_co2',Fmy+Fc[0])]:
 fit=fit_energy_balance_model_from_series(y,T,F)
 report['runs'][name]={'rmse':fit.rmse,'params':fit.params.to_dict(),'at_bound':fit.at_bound,'optimizer_success':fit.optimizer_success}
 print(name,report['runs'][name],flush=True)
(ROOT/'forcing_reference_results.json').write_text(json.dumps(report,indent=2)+'\n')
