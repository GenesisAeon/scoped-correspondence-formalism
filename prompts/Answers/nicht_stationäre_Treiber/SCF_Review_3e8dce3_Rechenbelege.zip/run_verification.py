"""Run all repository verify scripts on a separate local execution snapshot."""
from __future__ import annotations
import concurrent.futures, json, os, platform, subprocess, sys, time
from pathlib import Path
ROOT = Path(__file__).resolve().parent
REPO = ROOT / 'repo'
LOGS = ROOT / 'suite_logs'
LOGS.mkdir(exist_ok=True)
def run(path):
    start=time.monotonic()
    env=dict(os.environ, PYTHONPATH=str(REPO/'src'), OPENBLAS_NUM_THREADS='1', OMP_NUM_THREADS='1')
    try:
        p=subprocess.run([sys.executable,str(path)],cwd=REPO,env=env,text=True,capture_output=True,timeout=240)
        output=p.stdout+p.stderr; code=p.returncode
    except subprocess.TimeoutExpired as e:
        output=str(e);code=124
    (LOGS/(path.stem+'.log')).write_text(output)
    result={'script':path.name,'returncode':code,'seconds':round(time.monotonic()-start,3)}
    print(json.dumps(result),flush=True)
    return result
if __name__=='__main__':
    scripts=[p for p in sorted((REPO/'verification').glob('verify_*.py')) if p.name not in {'verify_formalism.py','verify_extensions.py'}]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        results=list(pool.map(run,scripts))
    report={'python':sys.version,'platform':platform.platform(),'scripts':results,'count':len(results),'passed':sum(r['returncode']==0 for r in results),'failed':sum(r['returncode']!=0 for r in results)}
    (ROOT/'suite_summary.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='scripts'}),flush=True)
