# Reproduktion der Review zu 3e8dce3

Geprüfter Commit: `3e8dce358e37017b375aaaae5b6f0bfe63f4d94f`.
Berechnungen am 22. September 2026; Bericht fertiggestellt am 23. September 2026.

Dieses Archiv enthält eigene Prüfprogramme, ihre Ergebnisse, die Ausführungslogs von 66 Verifikationsskripten und ein Hash-Verzeichnis der geprüften Repositorydateien. Quellcode und Daten des Repositorys sind nicht enthalten.

1. Archiv in ein leeres Arbeitsverzeichnis entpacken.
2. Mit eigenen GitHub-Zugriffsrechten `GenesisAeon/scoped-correspondence-formalism` in dessen Unterverzeichnis `repo` auschecken und den oben angegebenen Commit auswählen. Eine separate Arbeitskopie verwenden, da die Repository-Verifikationen ihre Ergebnisdateien neu schreiben.
3. Eine Python-Umgebung mit den Projektabhängigkeiten vorbereiten. In der Review wurden Python 3.12.14, NumPy 2.3.5 und SciPy 1.17.0 verwendet.
4. Im Arbeitsverzeichnis ausführen:

```bash
python independent_probes.py
python forcing_reference_probe.py
python run_verification.py
```

Die ersten beiden Programme schreiben `independent_results.json` und `forcing_reference_results.json`. Der Verifikationsrunner schreibt `suite_summary.json` und `suite_logs/`. Die vorhandenen Dateien dokumentieren die ursprüngliche Review-Ausführung und werden bei erneuter Ausführung überschrieben.

`independent_probes.py` prüft Zukunftsabhängigkeit von Intervallen, Zielwertabhängigkeit des COVID-Referenzmittels, die Fehlinterpretation eines offenen endlichen Profilscans und die Stationaritätsbehauptung bei einer Kernmasse von 1,68. `forcing_reference_probe.py` ist eine Sensitivitätsanalyse der Forcingreferenz, keine physikalisch korrigierte Klimaanalyse.

Der Runner lässt `verify_formalism.py` und `verify_extensions.py` aus: Die benötigte binäre DOCX-Datei war lokal nicht verfügbar. Ihre Existenz im Git-Baum wurde kontrolliert. Die beiden Skripte lassen sich bei vollständigem Checkout zusätzlich ausführen; ihr Ergebnis gehört nicht zu den hier dokumentierten 66 erfolgreichen Ausführungen.

`source_sha_manifest.json` enthält die Git-Blob-SHA-1-Werte der geprüften Quell-, Daten- und Verifikationsdateien. Für Bytes b berechnet sich dieser Hash als SHA-1 von `b"blob " + str(len(b)).encode() + b"\0" + b`.

Die numerischen Gegenbeispiele und die Verifikationslogs belegen die im Bericht genannten Befunde am fixierten Commit. Spätere Repositoryänderungen sind von dieser Review nicht erfasst.
