#!/usr/bin/env python3
"""Read-only SCF review reproductions; does not download or modify the repo.

python reproduce_g_review.py --repo /path/to/scf --output review_results.json
Optional: --sparc /path/to/local/raw/files (raw files are never copied).
The JSON records observed counterexamples, not a claim that they are fixed.
"""
from __future__ import annotations

import argparse
import dataclasses
import hashlib
import json
import math
import sys
from collections import Counter
from pathlib import Path
from unittest.mock import patch

import numpy as np
from scipy.integrate import quad
from scipy.optimize import least_squares


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--repo', type=Path, required=True)
    ap.add_argument('--sparc', type=Path)
    ap.add_argument('--output', type=Path, default=Path('review_results.json'))
    args = ap.parse_args()
    sys.path.insert(0, str(args.repo.resolve() / 'src'))
    from scoped_correspondence.astrophysics import BurkertProfile, NFWProfile
    from scoped_correspondence.astrophysics.units import G_ASTRO_PC
    from scoped_correspondence.astrophysics.acceleration_relations import effective_density
    from scoped_correspondence.validation import galaxy_pilot as gp, sparc_data as sd

    result = {'reviewed_commit': '5563e6778359cffdd6e844c8a5cd4eabc7c717dc'}
    b = BurkertProfile(0.05, 3000.)
    rows = []
    for x in (1e-6, 1e-4, .999999e-3, 1.000001e-3, .01, 1.):
        r = b.r0_pc*x
        # Independent density integral, on a fixed interval with no cancellation.
        integral = quad(lambda u: u*u/((1+x*u)*(1+(x*u)**2)), 0, 1,
                        epsabs=1e-13, epsrel=1e-13)[0]
        ref = 4*math.pi*b.rho0_msun_pc3*r**3*integral
        rows.append({'x': x, 'r_pc': r, 'mass_code': b.enclosed_mass(r),
                     'mass_quadrature': ref, 'mass_ratio': b.enclosed_mass(r)/ref,
                     'g_ratio': b.g(r)/(G_ASTRO_PC*ref/r**2),
                     'vc_ratio': b.circular_velocity(r)/math.sqrt(G_ASTRO_PC*ref/r)})
    result['burkert'] = {'cases': rows,
        'switch_mass_ratio': b.enclosed_mass(3.000003)/b.enclosed_mass(2.999997),
        'density_inverse_ratio_at_x_1e4': float(effective_density(b.g, .3)/b.density(.3))}
    nfw = NFWProfile(.05, 3000.)
    result['nfw_origin'] = {'g_at_zero': nfw.g(0.),
        'g_at_x_1e9': nfw.g(3e-6), 'right_limit': 2*math.pi*G_ASTRO_PC*.05*3000.}

    # Strictly self-generated synthetic fixtures; no real source rows embedded.
    metadata = 'Synthetic 5 10 .5 2 60 5 1 .01 2 inf 1 40 .5 3 100 5 1 SyntheticRef'
    mr = sd.parse_metadata_table('--------------------\n'+metadata)[0]
    values = ['Synthetic', 'nan', '1.00', '10.00', '1.00', '0.00', '0.00', '0.00', '1.00', '0.00']
    bounds = [(1,11),(13,18),(20,25),(27,32),(34,38),(40,45),(47,52),(54,59),(61,67),(69,76)]
    line = [' ']*76
    for value,(start,end) in zip(values,bounds):
        line[start-1:end] = value.rjust(end-start+1)
    cr = sd.parse_component_table('--------------------\n'+''.join(line))[0]
    result['parser_validation'] = {'nonfinite_SBeff_accepted': not math.isfinite(mr.SBeff_sollum_pc2),
        'nonfinite_component_D_accepted': not math.isfinite(cr.D_mpc)}
    # All 12 galaxies have meta D=10 and component D=100; selection still succeeds.
    metas = [dataclasses.replace(mr, galaxy=f'S{i:02}', SBeff_sollum_pc2=10.**(i/4)) for i in range(12)]
    comps = [dataclasses.replace(cr, galaxy=f'S{i:02}', D_mpc=100., R_kpc=j+1.)
             for i in range(12) for j in range(10)]
    result['parser_validation']['inconsistent_distances_selection_count'] = gp.select_frozen_sample(metas, comps).n_eligible_total

    negative = dataclasses.replace(cr, D_mpc=10., Vgas_kms=-1000.)
    r, gb = gp.baryon_g_kms2_per_pc([negative])
    gtot = float(gb[0]+BurkertProfile(.05, 3000).g(r[0]))
    result['invalid_total_clipping'] = {'g_total': gtot,
        'predicted_velocity_returned': float(gp._predicted_v_obs([negative], .05, 3000., .5, .7)[0])}

    # Solver failure must not become an ordinary scored model. Keep its numeric
    # output unchanged, only report failure; this isolates missing propagation.
    synt = [sd.SparcComponentRow('Synthetic', 10., float(r/1000), float(b.circular_velocity(r)),
                                1., 0., 0., 0., 0., 0.) for r in np.linspace(500,15000,20)]
    split = gp.train_test_split_outer(synt)
    normal = gp.evaluate_baselines_on_holdout('Synthetic', split)
    def failed_solver(*a, **kw):
        sol = least_squares(*a, **kw)
        sol.success = False
        sol.status = 0
        sol.message = 'Controlled review failure flag'
        return sol
    with patch('scipy.optimize.least_squares', failed_solver):
        failed = gp.evaluate_baselines_on_holdout('Synthetic', split)
        failed_a = gp.fit_burkert_descriptive(split.train_rows)
    result['fit_failure_propagation'] = {'descriptive_status': failed_a.status,
        'scores_unchanged_when_all_optimizers_report_failure': failed == normal,
        'predictive_fields': [f.name for f in dataclasses.fields(gp.PredictiveScore)]}

    if args.sparc:
        expected = {
            'SPARC_Lelli2016c.mrt': '5aa0501f6b0d881fa579030e315e7b5b6ef561a5bd3a07472f9929c7e5728243',
            'MassModels_Lelli2016c.mrt': '9108994b12cc401b94a1768beca61c53ec354779385c9c9cc571049f3043244c'}
        texts = {}; hashes = {}
        for name, sha in expected.items():
            raw = (args.sparc/name).read_bytes()
            hashes[name] = hashlib.sha256(raw).hexdigest()
            if hashes[name] != sha:
                raise ValueError(f'{name}: hash differs from reviewed dataset')
            texts[name] = raw.decode('ascii')
        metas = sd.parse_metadata_table(texts['SPARC_Lelli2016c.mrt'])
        comps = sd.parse_component_table(texts['MassModels_Lelli2016c.mrt'])
        sel = gp.select_frozen_sample(metas, comps)
        meta_by_id = {m.galaxy:m for m in metas}
        live = {'hashes': hashes, 'metadata_count': len(metas), 'component_count': len(comps),
            'selection': dataclasses.asdict(sel), 'negative_gas_rows': sum(c.Vgas_kms<0 for c in comps),
            'negative_gbar_rows_all': sum(sd.combine_baryonic_v2(c.Vgas_kms,c.Vdisk_kms,c.Vbul_kms)<0 for c in comps),
            'distance_mismatches': sum(abs(c.D_mpc-meta_by_id[c.galaxy].D_mpc)>1e-10 for c in comps),
            'metadata_line_lengths': dict(Counter(map(len, sd._data_section(texts['SPARC_Lelli2016c.mrt']))))}
        mode_b = []; optimizer_calls = []; winners = Counter(); nfw_robust = []
        for galaxy in sel.eval_galaxies:
            galrows = gp.galaxy_component_rows(comps, galaxy)
            split = gp.train_test_split_outer(galrows)
            def spy(fun, *a, **kw):
                sol = least_squares(fun, *a, **kw)
                lo,hi = np.array(kw['bounds'][0]),np.array(kw['bounds'][1])
                optimizer_calls.append({'galaxy':galaxy,'fun':fun.__name__,
                    'params':sol.x.tolist(),'cost':float(2*sol.cost),'success':bool(sol.success),
                    'boundary_hit':bool(np.any(np.minimum(abs(sol.x-lo),abs(sol.x-hi))<1e-6))})
                return sol
            with patch('scipy.optimize.least_squares', spy):
                scores = gp.evaluate_baselines_on_holdout(galaxy, split)
            mode_b.extend(dataclasses.asdict(s) for s in scores)
            winners[min(scores,key=lambda s:s.rmse_kms).baseline] += 1
            rt,gt = gp.baryon_g_kms2_per_pc(split.train_rows)
            vt=np.array([c.Vobs_kms for c in split.train_rows]); ev=np.array([c.e_Vobs_kms for c in split.train_rows])
            def nfw_resid(p):
                g=gt+NFWProfile(10.**p[0],1000*10.**p[1]).g(rt)
                return (np.sqrt(np.maximum(g,0)*rt)-vt)/ev
            sols=[least_squares(nfw_resid,x0=p,bounds=([-4.,-2.],[1.,2.5]))
                  for p in [(-1.5,.25),(-3.5,-1.5),(.5,2.)]]
            best=min(sols,key=lambda s:s.cost)
            nfw_check={'galaxy':galaxy,'best_params':best.x.tolist(),'best_chi2':float(2*best.cost)}
            lo=np.array([-4.,-2.]);hi=np.array([1.,2.5])
            hitlo=np.abs(best.x-lo)<1e-6;hithi=np.abs(best.x-hi)<1e-6
            if np.any(hitlo|hithi):
                lo2=lo-hitlo.astype(float);hi2=hi+hithi.astype(float)
                exp=[least_squares(nfw_resid,x0=p,bounds=(lo2,hi2)) for p in
                     [(-1.5,.25),(-3.5,-1.5),(.5,2.)]]
                eb=min(exp,key=lambda s:s.cost)
                re,ge=gp.baryon_g_kms2_per_pc(split.test_rows)
                ve=np.array([c.Vobs_kms for c in split.test_rows])
                vp=np.sqrt((ge+NFWProfile(10.**eb.x[0],1000*10.**eb.x[1]).g(re))*re)
                nfw_check['one_decade_expansion']={'bounds':[lo2.tolist(),hi2.tolist()],
                    'params':eb.x.tolist(),'chi2':float(2*eb.cost),
                    'still_at_boundary':bool(np.any(np.minimum(abs(eb.x-lo2),abs(eb.x-hi2))<1e-6)),
                    'test_rmse':float(np.sqrt(np.mean((vp-ve)**2)))}
            nfw_robust.append(nfw_check)
        live.update({'mode_b':mode_b, 'rmse_winners':dict(winners), 'optimizer_calls':optimizer_calls,
                     'nfw_same_bounds_three_start_check':nfw_robust})
        fits=[]
        for galaxy in sel.dev_galaxies+sel.eval_galaxies:
            galrows=gp.galaxy_component_rows(comps,galaxy)
            f=gp.fit_burkert_descriptive(galrows,galaxy)
            fits.append({**dataclasses.asdict(f),'min_x':min(c.R_kpc*1000/f.r0_pc for c in galrows),
                         'negative_gbar_points':sum(sd.combine_baryonic_v2(c.Vgas_kms,c.Vdisk_kms,c.Vbul_kms)<0 for c in galrows)})
        live['mode_a']=fits
        original=BurkertProfile._mass_bracket
        def corrected_bracket(self,x):
            v=original(self,x)
            return np.where(np.abs(x)<self.series_switch_x,2*v,v)
        # Counterfactual sensitivity check in memory only, no source changes.
        corrected_a=[];corrected_b=[]
        with patch.object(BurkertProfile,'_mass_bracket',corrected_bracket):
            for galaxy in sel.dev_galaxies+sel.eval_galaxies:
                corrected_a.append(dataclasses.asdict(gp.fit_burkert_descriptive(gp.galaxy_component_rows(comps,galaxy),galaxy)))
            for galaxy in sel.eval_galaxies:
                corrected_b.extend(dataclasses.asdict(s) for s in gp.evaluate_baselines_on_holdout(galaxy,gp.train_test_split_outer(gp.galaxy_component_rows(comps,galaxy))))
        live['burkert_fix_sensitivity']={
            'max_mode_a_relative_mu_change':max(abs(c['mu_h']/o['mu_h']-1) for c,o in zip(corrected_a,fits)),
            'max_mode_b_absolute_rmse_change':max(abs(c['rmse_kms']-o['rmse_kms']) for c,o in zip(corrected_b,mode_b))}
        result['real_pilot']=live
    args.output.write_text(json.dumps(result,indent=2,allow_nan=False,default=lambda x:x.item())+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='real_pilot'},indent=2))
    if 'real_pilot' in result:
        p=result['real_pilot']
        print('REAL PILOT',json.dumps({k:p[k] for k in ['metadata_count','component_count','rmse_winners','distance_mismatches','negative_gbar_rows_all','burkert_fix_sensitivity']},indent=2))
    print('Wrote',args.output)


if __name__=='__main__':
    main()
