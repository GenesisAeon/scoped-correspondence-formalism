#!/usr/bin/env python3
"""Exercise only the real-SPARC skip path through the unchanged suite runner.

Uses a temporary directory with a symlink to select that one existing script.
No source edits, network, raw data, or full-suite execution.
"""
import argparse
import contextlib
import importlib.util
import io
import json
import os
import tempfile
from pathlib import Path
from unittest.mock import patch

ap=argparse.ArgumentParser(description=__doc__)
ap.add_argument('--repo',type=Path,required=True)
ap.add_argument('--output',type=Path,default=Path('skip_counterexample.json'))
args=ap.parse_args()
repo=args.repo.resolve()
spec=importlib.util.spec_from_file_location('runner',repo/'scripts/run_verification_suite.py')
runner=importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
with tempfile.TemporaryDirectory() as directory:
    tmp=Path(directory)
    (tmp/'verify_sparc_real_local.py').symlink_to(repo/'verification/verify_sparc_real_local.py')
    out=io.StringIO()
    with patch.object(runner,'VER',tmp),patch.dict(os.environ,{'SCF_SPARC_RAW_DIR':str(tmp/'missing')}),contextlib.redirect_stdout(out):
        rc=runner.run_math_and_data('data')
    child=json.loads((tmp/'verify_sparc_real_local_results.json').read_text())
    result={'runner_returncode':rc,'runner_summary':json.loads(out.getvalue()),
            'child_all_skipped':child.get('all_skipped',False),
            'child_check_statuses':{name:c['status'] for name,c in child['checks'].items()}}
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
