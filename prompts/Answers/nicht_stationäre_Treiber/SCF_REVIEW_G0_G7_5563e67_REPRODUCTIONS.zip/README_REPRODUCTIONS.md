# Reproduktionen zum G0–G7-Review

Geprüfter SCF-Commit: `5563e6778359cffdd6e844c8a5cd4eabc7c717dc`.

1. Repository auf den geprüften Stand auschecken oder den aktuellen Stand bewusst als Vergleich verwenden.
2. Vorhandene SCF-Abhängigkeiten installieren. Die Gegenrechnung verwendet insbesondere NumPy und SciPy; geprüft mit Python 3.12.14, NumPy 2.3.5 und SciPy 1.17.0.
3. `python reproduce_g_review.py --repo /pfad/zum/repo --output eigene_resultate.json` ausführen.
4. Optional `--sparc /pfad/zu/lokalen/sparc-dateien` ergänzen. Benötigt werden die beiden offiziellen, im Review dokumentierten Dateien. Die Prüfsummen sind fest verankert. Kein automatischer Download.
5. `python reproduce_skip_summary.py --repo /pfad/zum/repo --output eigener_skip_test.json` demonstriert die Runner-Zusammenfassung bei fehlenden optionalen Daten. Dazu wird temporär ein symbolischer Link angelegt; unter Windows sind dafür gegebenenfalls entsprechende lokale Rechte erforderlich.

`review_results.json`, `skip_counterexample.json` und `verification_summary.json` sind die beobachteten Resultate des Reviews, keine handgesetzten Regressionserwartungen. Der vollständige Befund und die Abnahmekriterien stehen in `SCF_REVIEW_G0_G7_5563e67.md`.

Die Skripte verändern keine Repository-Quelldateien. Der Hauptlauf prüft den Effekt einer korrigierten Burkert-Reihe nur vorübergehend im Speicher. Der Skip-Test wählt über eine temporäre Verifikationsliste ein bestehendes Skript aus; er führt keine volle Suite aus. Keine Rohdateien oder Rohdatenzeilen sind in diesem Paket enthalten.

Nach Änderungen am Repository können Ergebnisse oder APIs abweichen. Die ausgegebenen Zähler und Werte sind Diagnoseinformationen. Für dauerhafte Regressionen die im Review genannten mathematischen Eigenschaften prüfen, nicht den fehlerhaften alten Output als Sollzustand festschreiben.
