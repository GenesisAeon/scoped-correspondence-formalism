# Übergabe an Claude-Code

Stand: 01.10.2026. Dieses Paket enthält Planung und unabhängige Kontrollrechnungen; es ist kein bereits implementierter Patch für SCF.

## Dateien

- `SCF_MUONIUM_GRAVITY_IMPLEMENTATION_PLAN.md`: vollständiger Auftrag MU0–MU7, Herleitungen, Quellen, Scope, API-Anschlüsse, Gegenbeispiele und Abnahme.
- `SCF_POLYEDER_SAKURAI_SATURN_ANSCHLUSSBEWERTUNG.md`: gesonderte Bewertung der von Johann beigefügten Kandidaten mit optionalen Umsetzungspaketen. Diese Optionen nicht automatisch zum Myonium-Auftrag hinzunehmen.
- `independent_controls.py`: eigenständige Kontrollrechnungen ohne SCF-Import; Python-Standardbibliothek.
- `independent_control_results.json`: beim Erstellen ausgeführte Ergebnisse, 29/29 Gruppen bestanden.
- `SHA256SUMS`: SHA-256 der fünf vorstehenden Dateien; Prüfsumme nicht auf sich selbst bezogen.

## Einstieg

1. Aktuellen Repo-Stand sowie `CLAUDE.md` und gegebenenfalls `AGENTS.md` lesen. Der hier recherchierte Stand war `4a7ed38640ac7d393017eb5556291c879c3bceac`.
2. Gewählten Plan lesen und Kontrollfälle unabhängig herleiten.
3. Das Kontrollskript ausführen; seine Ergebnisse dienen als Oracle, nicht als Ersatz für Produktionsprüfungen.
4. Paketweise und additiv implementieren. Bei Übernahme gelten die Code- und Dokumentationslizenzen des Ziel-Repos; fremde Quellenartefakte separat prüfen.
5. Synthetische, algebraische und reale Evidenz auseinanderhalten. Blockierte Datenzweige sichtbar lassen.

```bash
python independent_controls.py --output independent_control_results.json
```

17 Gruppen betreffen Myonium, jeweils 4 die Polyeder-, Sakurai- und Saturn-Kontrollen. Die Checks zertifizieren weder ein echtes Gravitationsresultat noch ein vollständiges Polyeder oder eine Stern-/Planetenphysik-Simulation. Eine neue reale Datenauswertung, Produktionsimplementierung und Repo-CI wurden in dieser Übergabe nicht durchgeführt.

## Zwei zentrale Korrekturen, die nicht verloren gehen dürfen

- Zwei Flugzeiten können einen linearen Phasenoffset trennen, aber bei kommensurablen Zeiten weiterhin globale Phasenaliase behalten. Rangprüfung und globale Identifizierbarkeit sind verschiedene Aussagen.
- Eine lineare gekoppelte Speicher-Dynamik kann bereits einen Puls mit Erholung erzeugen. Nichtlinearität ist anhand zusätzlicher unterscheidender Befunde zu begründen.
