#!/usr/bin/env python3
"""Independent hand-derived controls for planning; no SCF imports or real data.

Run: python independent_controls.py --output independent_control_results.json
This is an oracle notebook in executable form, not a production implementation.
"""
from fractions import Fraction as Q
import argparse
import cmath
import json
import math
from pathlib import Path

CASES = []

def close(a, b, rel=2e-12, abs_tol=2e-14):
    assert math.isclose(a, b, rel_tol=rel, abs_tol=abs_tol), (a, b)

def record(cid, title, result):
    CASES.append({'id': cid, 'title': title, 'passed': True, 'values': result})

def rank(rows):
    a = [[Q(v) for v in row] for row in rows]
    r = 0
    for j in range(len(a[0])):
        pivot = next((i for i in range(r, len(a)) if a[i][j]), None)
        if pivot is None:
            continue
        a[r], a[pivot] = a[pivot], a[r]
        c = a[r][j]
        a[r] = [v / c for v in a[r]]
        for i in range(len(a)):
            if i != r:
                c = a[i][j]
                a[i] = [x - c*y for x, y in zip(a[i], a[r])]
        r += 1
        if r == len(a):
            break
    return r

def nll(n, lam):
    assert isinstance(n, int) and n >= 0 and lam >= 0 and math.isfinite(lam)
    if lam == 0:
        return 0.0 if n == 0 else math.inf
    return lam - n*math.log(lam) + math.lgamma(n + 1)

def deviance(n, lam):
    if lam == 0:
        return 0.0 if n == 0 else math.inf
    return 2*(lam - n + (n*math.log(n/lam) if n else 0))

def components(n, edges):
    neighbors = [set() for _ in range(n)]
    for a, b in edges:
        neighbors[a].add(b)
        neighbors[b].add(a)
    unseen = set(range(n)); sizes = []
    while unseen:
        todo = [unseen.pop()]; size = 0
        while todo:
            a = todo.pop(); size += 1
            new = neighbors[a] & unseen
            unseen -= new; todo.extend(new)
        sizes.append(size)
    return sorted(sizes), sorted(map(len, neighbors))

def muonium():
    delta = Q(1, 10); eta = 2*delta/(2+delta)
    assert eta == Q(2, 21) and eta != delta
    record('MU-C01', 'delta and Eotvos parameter', {'delta': str(delta), 'eta': str(eta)})

    z0, u0, a, T = Q(7, 3), Q(-11, 5), Q(981, 100), Q(11, 2500000)
    def z(t): return z0 + u0*t + a*t*t/2
    displacement = z(2*T) - 2*z(T) + z(0)
    assert displacement == a*T*T
    record('MU-C02', 'three-plane finite difference', {'displacement_m_exact': str(displacement)})

    tau, d, v = Q(11, 5000000), Q(1, 10000000), Q(2180)
    phase = 2*math.pi*float(displacement/d)
    close(phase, 0.011933126066360385)
    assert v*T == Q(1199, 125000)
    record('MU-C03', 'SI reference values; illustrative inputs', {
        'tau_s': float(tau), 'T_s': float(T), 'pitch_m': float(d),
        'v_m_per_s': float(v), 'gap_m': float(v*T),
        'one_lifetime_sag_pm': float(a*tau*tau/2)*1e12,
        'relative_displacement_pm': float(displacement)*1e12, 'phase_rad': phase})

    survival = math.exp(-float(2*T/tau))
    close(survival, 0.01831563888873418)
    # Dimensionless shot-noise standard deviation f(x)=exp(x)/x^2, x=T/tau.
    f = lambda x: math.exp(x)/(x*x)
    assert f(2) < f(1) and f(2) < f(3)
    assert Q(1)-Q(2, 2) == 0  # logarithmic derivative at x=2
    record('MU-C04', 'survival and conditional design optimum', {
        'survival': survival, 'optimal_T_over_tau': 2, 'sigma_factors_x_1_2_3': [f(x) for x in (1,2,3)]})

    e = Q(1,100); bias = (1+e)**2 - 1
    assert bias == Q(201,10000)
    # SI -> cm, milliseconds: a*1e-4; T*1e3; d*1e2; phase invariant.
    assert a*T*T/d == (a*Q(1,10000))*(T*1000)**2/(d*100)
    record('MU-C05', 'unit covariance and velocity-calibration bias', {'relative_bias_for_1pct_velocity_error': float(bias)})

    ek = (Q(1)+Q(1,4))/2; kmean = 1/(Q(3,2)**2)
    assert ek == Q(5,8) and kmean == Q(4,9) and ek/kmean == Q(45,32)
    phasor = (cmath.exp(0j)+cmath.exp(1j*math.pi))/2
    assert abs(phasor) < 1e-15
    record('MU-C06', 'averaging velocities and averaging phases fail', {
        'mean_inverse_v_squared': str(ek), 'inverse_mean_v_squared': str(kmean), 'cancelling_phasor_modulus': abs(phasor)})

    L = math.log(2); s1, s2 = math.exp(-2*L), math.exp(-L)
    w1, w2 = s1/(s1+s2), s2/(s1+s2)
    close(w1, 1/3); close(w2, 2/3)
    close(w1 + w2/4, .5)
    record('MU-C07', 'decay changes detected velocity distribution', {
        'detected_weights': [w1,w2], 'detected_mean_inverse_v_squared': w1+w2/4})

    assert nll(0,0) == 0 and math.isinf(nll(1,0))
    for n, lam in [(0,2.0),(3,2.0),(5,7.0)]:
        close(2*(nll(n,lam)-nll(n,float(n))), deviance(n,lam))
    close(deviance(0,2), 4)
    record('MU-C08', 'Poisson boundary and likelihood-ratio deviance', {
        'nll_zero_zero': 0, 'nll_positive_zero': 'infinity', 'deviance_zero_two': 4})

    assert rank([[1,1]]) == 1 and rank([[1,1],[4,1]]) == 2
    assert Q(1)+2 == Q(2)+1 == 3
    p1,p2 = Q(3),Q(6); slope=(p2-p1)/3; offset=p1-slope
    assert (slope,offset) == (1,2)
    record('MU-C09', 'unwrapped phase: offset degeneracy and two times', {
        'single_time_rank': 1, 'two_time_rank': 2, 'recovered_A_b': [1,2]})

    assert rank([[1,1,1],[4,4,1],[9,9,1]]) == 2
    record('MU-C10', 'gravity-like nuisance survives multiple flight times', {'rank': 2, 'parameter_count': 3})

    A,b,B = Q(3,1000),Q(1,100),Q(2,1000)
    pplus,pminus = A+b,-A+b
    assert (pplus-pminus)/2 == A
    polluted = ((A+B+b)-(-A-B+b))/2
    assert polluted == Q(5,1000)
    record('MU-C11', 'reversal removes even but retains odd nuisance', {
        'phases_without_nuisance': [float(pplus),float(pminus)], 'inferred_with_odd_nuisance': float(polluted)})

    baseline,C = Q(100),Q(1,5)
    expected=[baseline*(1+C),baseline,baseline*(1-C),baseline]
    total=sum(expected)
    info_four = 2*baseline*C*C
    info_quadrature = total*C*C
    assert expected == [120,100,80,100] and info_four == 8 and info_quadrature == 16
    record('MU-C12', 'scan-dependent Fisher information at known phase', {
        'expected_counts_four_steps': list(map(float,expected)), 'I_phi_four_steps':8, 'I_phi_quadrature':16})

    Nrequired = 1/(.35**2*(.01*phase)**2)
    close(Nrequired,573265035.1353949)
    displacement_1pct = float(displacement)*.01
    align_relative_bias = 1e-12/float(displacement)
    record('MU-C13', 'ideal local sensitivity; no exposure forecast', {
        'detected_signal_events_for_1pct': Nrequired,
        'phase_1pct_rad': .01*phase,'alignment_1pct_m':displacement_1pct,
        'relative_bias_one_pm_alignment':align_relative_bias})

    alias_step = float(d/(T*T))
    kappa=2*math.pi*float(T*T/d)
    for alpha in [0,.3,2.7]:
        close(math.cos(alpha+kappa*float(a)), math.cos(alpha+kappa*(float(a)+alias_step)))
    record('MU-C14', 'single-time likelihood aliases', {'acceleration_alias_step_m_per_s2':alias_step})

    # Balanced quadrature differences estimate SIN(phi); ARCSIN has branches.
    phi=.03; C=.2; B=1000
    lam_plus=B*(1+C*math.cos(math.pi/2+phi))
    lam_minus=B*(1+C*math.cos(3*math.pi/2+phi))
    s_est=(lam_minus-lam_plus)/(2*B*C)
    close(s_est,math.sin(phi)); close(math.asin(s_est),phi)
    record('MU-C15', 'signed quadrature readout on declared local branch', {'injected_phase':phi,'recovered_local_phase':math.asin(s_est)})

    # A zero contrast source has no phase derivative, whatever its event count.
    derivatives=[-1000*0.0*math.sin(alpha+.7) for alpha in [0,1,2,3]]
    assert sum(x*x/1000 for x in derivatives) == 0
    record('MU-C16', 'zero contrast gives no acceleration information', {'fisher_information':0})

    # The two-time rank check does not eliminate global aliases if T2=2*T1.
    for multiplier in [1,4]:
        close(math.cos(multiplier*.31), math.cos(multiplier*(.31+2*math.pi)))
    record('MU-C17', 'two commensurate flight times retain global phase aliases', {'K_multipliers':[1,4], 'phase_alias_step':2*math.pi})

def candidates():
    chi=24-36+8
    assert chi == -4 and Q(2-chi,2)==3 and 8*9 == 2*36 and 24*3 == 2*36
    record('TP-C01', 'Euler arithmetic conditional on manifold assumptions', {'chi':chi,'conditional_genus':3})
    cycle8=[(i,(i+1)%8) for i in range(8)]
    two4=[(i,4*(i//4)+(i+1)%4) for i in range(8)]
    sizes8,degs8=components(8,cycle8); sizes4,degs4=components(8,two4)
    assert degs8==degs4==[2]*8 and sizes8==[8] and sizes4==[4,4]
    record('TP-C02', 'same graph counts and degrees; nonisomorphic graphs', {'component_sizes_C8':sizes8,'component_sizes_two_C4':sizes4})
    T=lambda v:(v[1],-v[0],-v[2])
    v=(1,2,3); out=v
    for _ in range(4): out=T(out)
    assert out==v and T(v)==(2,-1,-3) and T(T(v))==(-1,-2,3)
    # det([[0,1,0],[-1,0,0],[0,0,-1]])=-1.
    record('TP-C03','order-four rotoreflection is not a proper rotation',{'generator_determinant':-1,'order':4})
    # For A=(0,0,0), B=(1,0,0), C=(0,1,0), D=(1,1,epsilon), determinant=epsilon.
    eps=Q(1,10**12)
    assert eps != 0 and rank([[1,0,0],[0,1,0],[1,1,eps]])==3
    assert rank([[1,0,0],[0,1,0],[1,1,0]])==2
    record('TP-C04','exact coplanarity versus tiny violation',{'nonzero_determinant':str(eps)})

    t=math.log(2); fuel=math.exp(-2*t); energy=2*(math.exp(-t)-math.exp(-2*t)); emitted=(1-math.exp(-t))**2
    close(fuel,.25); close(energy,.5); close(emitted,.25); close(fuel+energy+emitted,1)
    derivative=2*(-math.exp(-t)+2*math.exp(-2*t)); close(derivative,0)
    record('SK-C01','triggered release-relaxation control; not a stellar model',{'peak_time':t,'fuel_at_peak':fuel,'stored_energy_at_peak':energy,'emitted_energy_at_peak':emitted})
    close(math.e*math.exp(-1),1)
    record('SK-C02','one-band extinction-luminosity degeneracy',{'L_tau_pairs':[[1,0],[math.e,1]],'same_normalized_flux':1})
    assert Q(4)**3 == Q(8)**2
    close(4/(8**(2/3)),1)
    record('SK-C03','toy transformed-radius scaling at fixed temperature, wind speed and clumping',{'radius_factor':4,'luminosity_factor':16,'mass_loss_factor':8,'transformed_radius_factor':1})
    # Distinct extinction coefficients -> rank 2 for log-flux = log(L)-k*tau.
    assert rank([[1,-1],[1,-2]])==2 and rank([[1,-1],[1,-1]])==1
    record('SK-C04','two calibrated bands can break the simplest extinction degeneracy',{'rank_distinct_coefficients':2,'rank_equal_coefficients':1})

    # Dimensionless linear beta-plane wave: omega=U*k-beta*k/(k^2+l^2+Ld^-2).
    k,l,U,beta,invLd2=Q(6),Q(0),Q(1),Q(36),Q(0)
    omega=U*k-beta*k/(k*k+l*l+invLd2)
    assert omega==0  # No growth-rate selection follows from this equality.
    record('SA-C01','stationary toy Rossby phase speed does not select growth',{'k':6,'omega':0})
    # Real amplitude of exp(i*m*theta): DFT a_m=epsilon/2.
    n,m,epsilon,shift=64,6,.2,.17
    def coeff(theta0):
        return sum(epsilon*math.cos(m*(2*math.pi*j/n-theta0))*cmath.exp(-2j*math.pi*m*j/n) for j in range(n))/n
    c0,c1=coeff(0),coeff(shift)
    close(abs(c0),epsilon/2); close(abs(c1),epsilon/2)
    assert abs(c1-c0*cmath.exp(-1j*m*shift)) < 1e-13
    record('SA-C02','Fourier magnitude is rotation-invariant; phase is not',{'abs_mode_6':abs(c0),'phase_shift_rad':cmath.phase(c1/c0)})
    # On quarter-period wedge, exp(i*m*pi/2)=1 requires m in 4Z.
    assert abs(cmath.exp(1j*6*math.pi/2)-1)>1.9
    assert abs(cmath.exp(1j*8*math.pi/2)-1)<1e-13
    record('SA-C03','quarter-domain boundary excludes m=6',{'m6_allowed':False,'m8_allowed':True})
    # On N=12 samples, cos(6 theta) and cos(18 theta) alias exactly.
    err=max(abs(math.cos(6*2*math.pi*j/12)-math.cos(18*2*math.pi*j/12)) for j in range(12))
    assert err<1e-13
    record('SA-C04','sampling alias is not physical mode identity',{'sample_count':12,'aliased_modes':[6,18],'max_difference':err})

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--output',type=Path)
    args=ap.parse_args(); muonium(); candidates()
    report={'schema_version':1,'kind':'independent_planning_controls','not_production_tests':True,
            'date':'2026-10-01','counts':{'passed':len(CASES),'failed':0},'cases':CASES,
            'limits':['No SCF production code imported.','No real experimental data used.',
                      'No confidence-interval coverage study performed.','No polyhedral embedding certified.',
                      'No stellar or planetary simulation validated.']}
    if args.output: args.output.write_text(json.dumps(report,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
    print(f'{len(CASES)}/{len(CASES)} independent control groups passed')
