from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent;d=json.load(open(R/'independent_results.json'));e=d['energy_balance']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
fig,ax=plt.subplots(1,2,figsize=(12.5,4.8),layout='constrained')
fig.suptitle('SCF: unabhängige Gegenrechnungen zu Commit f8e249f',fontsize=16,fontweight='bold')
a=ax[0];a.plot(e['years'],e['observations'],color='#273449',lw=1.2,label='NOAA-Beobachtungen');a.plot(e['years'],e['original_prediction'],color='#c56b21',lw=2,label='Gespeicherter Fit: RMSE 0,154 °C');a.plot(e['years'],e['refit_prediction'],color='#087f8c',lw=2,label='Exakte Propagation + Refit: 0,090 °C');a.set_title('Gleiches Modell, gleiche Daten, verbesserte Optimierung',fontsize=11);a.set_ylabel('Temperaturanomalie [°C]');a.set_xlabel('Jahr');a.grid(alpha=.18);a.legend(fontsize=9,loc='upper left');a.text(.03,.02,'Anpassung auf 1959–2025, keine Prognoseprüfung.\nRefit an α-Untergrenze: kein physikalischer Parameterschätzer.',transform=a.transAxes,fontsize=8,color='#3e4b5d')
b=ax[1];rows=d['buffer_equal_integral'];taus=[x['tau'] for x in rows];area=[x['z_min'] for x in rows]
fixed={.05:-.08079781553520923,.2:-.26491806119250727,.5:-.49461774868919217,1:-.6947528522999472,2:-.8576460705475705,5:-.965466774905735}
b.plot(taus,[fixed[t] for t in taus],'o-',color='#c56b21',label='Gleiche Spitzenhöhe (Repo-Fall)');b.plot(taus,area,'s-',color='#087f8c',label='Gleiche Gesamtlast (Gegenkontrolle)');b.axhline(-.5,color='#627185',ls='--',lw=1,label='Sicherheitsgrenze b = −0,5');b.set_xscale('log');b.set_xlabel('Pulsbreite τ (kleiner = kürzer)');b.set_ylabel('Kleinster Pufferzustand');b.set_title('Die Schlussfolgerung hängt vom kontrollierten Vergleich ab',fontsize=11);b.grid(alpha=.18);b.legend(fontsize=9,loc='center left');b.text(.03,.03,'Synthetisches lineares Puffermodell; r = 1.\nFläche A√π τ: konstant nur bei der Gegenkontrolle.',transform=b.transAxes,fontsize=8,color='#3e4b5d')
fig.savefig(R/'SCF_Review_f8e249f_Gegenrechnungen.png',dpi=180)
