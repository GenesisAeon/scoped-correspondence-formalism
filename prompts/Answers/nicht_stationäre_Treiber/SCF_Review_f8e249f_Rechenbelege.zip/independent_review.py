"""Independent scientific probes at SCF commit f8e249f; no repository changes."""
from pathlib import Path
import json,sys,csv,math
import numpy as np
from scipy.linalg import expm
from scipy.optimize import least_squares
from scipy.interpolate import interp1d
ROOT=Path(__file__).resolve().parent; REPO=ROOT/'repo'; sys.path.insert(0,str(REPO/'src'))
from scoped_correspondence.dynamics.rate_dependent import rate_induced_tipping_cubic_example
from scoped_correspondence.dynamics.energy_balance import _integrate_Ts,load_annual_co2
from scoped_correspondence.dynamics.etas import load_catalog,etas_branching_ratio,compensator_g
from scoped_correspondence.viability.rate_dependent_buffer import run_buffer_spike_trajectory
from scoped_correspondence.validation.covid_renewal import discretized_generation_interval,wallinga_lipsitch_r
OUT={}
def save():
 (ROOT/'independent_results.json').write_text(json.dumps(OUT,indent=2)+'\n')
OUT['rate_sweep']=[rate_induced_tipping_cubic_example(r).to_dict() for r in [.6,.7,.8,.9]]
print('rate:',[(x['r'],x['switched']) for x in OUT['rate_sweep']],flush=True);save()
# Exact propagation of the repository's linear ODE under the SAME piecewise-linear forcing.
co2=load_annual_co2(REPO/'data/noaa_mauna_loa_co2_annual_1959_2025.txt')
lines=[s for s in (REPO/'data/noaa_global_temp_anomaly_1880_2025.csv').read_text().splitlines() if s and not s.startswith('#')]
temp={int(x['Year']):float(x['Departure from Average']) for x in csv.DictReader(lines)}
years=np.array(sorted(set(co2)&set(temp))); y=np.array([temp[a] for a in years]); F=5.35*np.log(np.array([co2[a] for a in years])/co2[years[0]])
assert np.all(np.diff(years)==1)
def exact(q):
 Cs,Cd,a,g=np.exp(q[:4]);T0=q[4]
 A=np.zeros((4,4));A[0,:3]=[-(a+g)/Cs,g/Cs,1/Cs];A[1,:2]=[g/Cd,-g/Cd];A[2,3]=1
 E=expm(A); state=np.array([T0,T0]);out=[T0]
 for k in range(len(F)-1):
  state=(E@np.r_[state,F[k],F[k+1]-F[k]])[:2];out.append(state[0])
 return np.array(out)
def encode(p):return np.r_[np.log([p[k] for k in ['C_s','C_d','alpha','gamma']]),p['T0']]
references=json.load(open(ROOT/'reference_values.json'))
orig=references['energy_balance_fit']
current=json.load(open(REPO/'verification/verify_energy_balance_results.json'))['report']['checks']['fit_and_aerosol_undershoot']['detail']
starts=[encode(orig['params']),encode(current['params']),np.r_[np.log([5,70,1.2,.7]),-.2]]
fits=[]
for q in starts:
 z=least_squares(lambda q:exact(q)-y,q,bounds=([-5,-5,-10,-10,-3],[15,15,5,5,3]),xtol=1e-11,ftol=1e-11,gtol=1e-11,max_nfev=1000)
 pred=exact(z.x)
 fits.append({'params':dict(zip(['C_s','C_d','alpha','gamma','T0'],[*np.exp(z.x[:4]),z.x[4]])),'rmse':float(np.sqrt(np.mean((pred-y)**2))),'success':bool(z.success),'optimality':float(z.optimality),'nfev':z.nfev,'early_residual':float(np.mean(y[:10]-pred[:10])),'recent_residual':float(np.mean(y[-10:]-pred[-10:])),'singular_values':np.linalg.svd(z.jac,compute_uv=False).tolist()})
print('ebm refits:',fits,flush=True)
best=min(fits,key=lambda v:v['rmse']);q=encode(best['params']);fine=_integrate_Ts(np.arange(len(y)),interp1d(np.arange(len(y)),F),*np.exp(q[:4]),q[4]);orig_exact=exact(encode(orig['params']))
OUT['energy_balance']={'original':orig,'local_default':current,'exact_refits':fits,'original_param_exact_rmse':float(np.sqrt(np.mean((orig_exact-y)**2))),'refit_ivp_rmse':float(np.sqrt(np.mean((fine-y)**2))),'refit_ivp_max_difference':float(np.max(np.abs(fine-exact(q)))),'years':years.tolist(),'observations':y.tolist(),'original_prediction':orig_exact.tolist(),'refit_prediction':exact(q).tolist()};save()
# A finite-horizon fit constrains only a small fraction of this near-p=1 infinite tail.
e=references['etas_fit'];p=e['params'];T=e['T_days'];times,mags=load_catalog(REPO/'data/usgs_earthquakes_m6plus_2000_2026.csv',m0=6)
branch=[]
for pp in [1.015,1.0249207287200637,1.04,1.06]:
 branch.append({'p':pp,'branching_ratio':etas_branching_ratio(p['K'],p['c'],pp,p['alpha'],mags,6),'fraction_kernel_mass_by_T':float(compensator_g(np.array(T),p['c'],pp)/(p['c']**(1-pp)/(pp-1)))})
OUT['etas_tail']={'fit':e,'sensitivity_fixed_other_params_not_refit':branch,'tied_timestamps':int(np.sum(np.diff(times)==0))};print('etas tail:',branch,flush=True);save()
# Equal total additional load (integral=1) is a complementary buffer control.
OUT['buffer_equal_integral']=[]
for tau in [.05,.2,.5,1,2,5]:
 h=1/(math.sqrt(math.pi)*tau);r=run_buffer_spike_trajectory(1,0,0,0,h,tau)
 OUT['buffer_equal_integral'].append({'tau':tau,'height':h,'z_min':r.z_min,'area':1})
OUT['generation_interval_sensitivity']=[{'mean':mean,'sd':mean*2.9/4.7,'R_for_r_0.121004':wallinga_lipsitch_r(.121004,discretized_generation_interval(mean,mean*2.9/4.7,40))} for mean in [3,4.7,7]]
print('buffer:',OUT['buffer_equal_integral'],flush=True);print('renewal:',OUT['generation_interval_sensitivity'],flush=True);save()

# One-dimensional counterexample and objective gradient at the stored parameter vector.
q=encode(orig['params'])
def cost(q): return .5*np.sum((exact(q)-y)**2)
h=1e-5
gradient=[float((cost(q+np.eye(5)[i]*h)-cost(q-np.eye(5)[i]*h))/(2*h)) for i in range(5)]
a=exact(q+np.array([0,0,0,0,1]))-exact(q)
delta=float(a@(y-exact(q))/(a@a))
q2=q.copy();q2[4]+=delta
OUT['energy_balance']['original_cost_gradient_logparameters']=gradient
OUT['energy_balance']['T0_only_exact_improvement']={'T0_delta':delta,'T0_new':float(q2[4]),'rmse':float(np.sqrt(np.mean((exact(q2)-y)**2)))}
save()
