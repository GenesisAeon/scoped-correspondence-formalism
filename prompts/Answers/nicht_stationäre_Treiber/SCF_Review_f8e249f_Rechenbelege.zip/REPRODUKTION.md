# Rechenbelege zur SCF-Prüfung f8e249f

Geprüfter Commit: f8e249fa49a6080f0edde7bff0d7138dc00e4616, 21.09.2026.

Enthalten sind eigene Rechenskripte, numerische Referenzwerte, Ergebnisdaten und Prüfprotokolle. Repository-Code und Rohdatendateien sind nicht dupliziert.

Für eine Wiederholung das autorisierte Repository unter `repo/` neben diesen Skripten bereitstellen und den genannten Commit auschecken. Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0 und Matplotlib waren in der Prüfungsumgebung vorhanden. Benötigt werden NumPy, SciPy und für die Grafik Matplotlib.

1. `python run_verification.py` führt die 62 Repository-Suiten aus und schreibt Protokolle. Achtung: Die Repo-Suiten überschreiben ihre eigenen lokalen Ergebnis-JSONs; deshalb einen separaten Checkout verwenden. Der Runner nutzt vier Prozesse und 240 Sekunden Zeitlimit je Skript.
2. `OPENBLAS_NUM_THREADS=1 python independent_review.py` erzeugt die Gegenrechnungen. Die gespeicherten ursprünglichen Zahlen werden aus `reference_values.json` bezogen; der unveränderte lokale EBM-Fit aus dem vorherigen Suite-Lauf. Die exakte EBM-Propagation verändert weder die Gleichungen noch die lineare Interpolation der Anregung. Der gemeinsame Refit ist positiv beschränkt; alpha erreicht die Untergrenze exp(-10), ein bewusst offen ausgewiesener Randbefund.
3. `python make_review_figure.py` zeichnet die Gegenüberstellungen aus `independent_results.json`. Die Werte für konstante Spitzenhöhe stammen aus der überprüften Repository-Puffersuite; die Werte für konstante Gesamtlast aus der eigenen Gegenrechnung.

Die enthaltene `suite_summary.json` protokolliert den tatsächlichen Lauf: 60 erfolgreiche Suiten, zwei ausschließlich dokumentbezogene Fehlschläge wegen derselben nicht lokal verfügbaren DOCX. `document_link_check.json` hält fest, dass dieses Linkziel im Git-Baum vorhanden ist. Die binäre Datei konnte über den verwendeten GitHub-Zugang nicht heruntergeladen werden. Ein vollständiger Git-Checkout enthält sie; die lokale Einschränkung ist kein nachgewiesener Repo-Fehler. Die mathematischen und datenbezogenen Checks beider betroffenen Suiten waren erfolgreich. Der vollständige Git-Baum ist als Prüfnachweis beigefügt.

`reference_values.json` enthält ausgewählte Zahlen der ursprünglichen EBM- und ETAS-Ergebnisberichte zur Gegenüberstellung, keine neuen Datenerhebungen. Zahlen in den Gegenrechnungen sind Anpassungen bzw. Sensitivitäten, keine prospektiv validierten Vorhersagen. ETAS-Tail-Sensitivität variiert p bei festen übrigen Koeffizienten, also kein Konfidenzintervall. Die Renewal-Sensitivität variiert angenommene Intervalle, also ebenfalls kein Konfidenzintervall. Die Puffer- und R-Tipping-Fälle sind synthetisch.
