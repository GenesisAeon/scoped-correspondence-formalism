#!/usr/bin/env python3
"""Independent plan oracles. Python >=3.10, standard library, no SCF imports.

These checks validate this plan's arithmetic, not an SCF implementation or CI.
Code: GPL-3.0-or-later. Plan/documentation: CC-BY-4.0.
"""
from fractions import Fraction as F
from itertools import product
from math import exp, isclose
from pathlib import Path
import argparse
import json

RESULTS = {}


def record(key, values):
    if key in RESULTS:
        raise ValueError(key)
    RESULTS[key] = values


def rank(matrix):
    a = [[F(v) for v in row] for row in matrix]
    r = 0
    for col in range(len(a[0])):
        pivot = next((i for i in range(r, len(a)) if a[i][col]), None)
        if pivot is None:
            continue
        a[r], a[pivot] = a[pivot], a[r]
        d = a[r][col]
        a[r] = [x / d for x in a[r]]
        for i in range(len(a)):
            if i != r:
                d = a[i][col]
                a[i] = [x - d*y for x, y in zip(a[i], a[r])]
        r += 1
        if r == len(a):
            break
    return r


def weighted_q(scores, weights, test_weight, alpha):
    # The missing test score contributes mass at +infinity.
    threshold = (1-alpha) * (sum(weights) + test_weight)
    cumulative = F(0)
    for score, weight in sorted(zip(scores, weights)):
        cumulative += weight
        if cumulative >= threshold:
            return F(score)
    return None  # Tagged infinity, not a missing result.


def distribution(states, fn):
    out = {}
    for state, probability in states:
        value = fn(state)
        out[value] = out.get(value, F(0)) + probability
    return out


def tv(a, b):
    return sum(abs(a.get(k, 0)-b.get(k, 0)) for k in a.keys() | b.keys()) / 2


def dsep(edges, left, right, conditioned=()):
    # Ancestral moral graph criterion, independent small-graph oracle.
    conditioned = set(conditioned)
    ancestors = set(left) | set(right) | conditioned
    while True:
        enlarged = ancestors | {a for a, b in edges if b in ancestors}
        if enlarged == ancestors:
            break
        ancestors = enlarged
    adj = {x: set() for x in ancestors}
    for a, b in edges:
        if a in ancestors and b in ancestors:
            adj[a].add(b)
            adj[b].add(a)
    for child in ancestors:
        parents = [a for a, b in edges if b == child and a in ancestors]
        for a, b in product(parents, repeat=2):
            if a != b:
                adj[a].add(b)
    reached, todo = set(), list(set(left)-conditioned)
    while todo:
        node = todo.pop()
        if node in reached or node in conditioned:
            continue
        reached.add(node)
        todo.extend(adj[node]-reached-conditioned)
    return not (reached & set(right))


def run():
    d = list(map(F, [-1, 0, 1, 2]))
    mean = sum(d)/len(d)
    c = [x-mean for x in d]
    g0 = sum(x*x for x in c)/4
    g1 = sum(c[i]*c[i-1] for i in range(1, 4))/4
    lrv = g0+g1  # Bartlett L=1: 2*(1/2)*gamma_1.
    se = F(5, 8)
    assert (mean, g0, g1, lrv, lrv/4, mean/se) == (
        F(1, 2), F(5, 4), F(5, 16), F(25, 16), F(25, 64), F(4, 5))
    assert se*se == lrv/4
    record('J-C01', dict(mean=mean, gamma0=g0, gamma1=g1, long_run_variance=lrv,
                         variance_of_mean=lrv/4, standard_error=se, dm=mean/se))

    p = [F(1, 100), F(4, 100), F(3, 100)]
    order = sorted(range(3), key=p.__getitem__)
    adjusted, previous = [None]*3, F(0)
    for j, i in enumerate(order):
        previous = min(F(1), max(previous, (3-j)*p[i]))
        adjusted[i] = previous
    assert adjusted == [F(3, 100), F(6, 100), F(6, 100)]
    record('J-C02', dict(raw=p, holm=adjusted))

    dimensions = [[0, 1, 1], [1, 0, -2]]  # T, length, g; L and time rows.
    v = [2, -1, 1]
    assert rank(dimensions) == 2
    assert all(sum(a*b for a, b in zip(row, v)) == 0 for row in dimensions)
    accel, gravity = (0, 1, -2), (-1, 3, -2)  # M,L,T
    assert tuple(a-b for a, b in zip(accel, gravity)) == (1, -2, 0)
    record('J-C03', dict(rank=2, nullity=1, pi_exponents=v,
                         surface_density_dimensions=[1, -2, 0]))

    def reservoir(m, q, k, t):
        return m*exp(-k*t)+q/k*(1-exp(-k*t))
    annual = reservoir(3, 5, 2, .4)
    daily = reservoir(3, 5/365, 2/365, .4*365)
    assert isclose(annual, daily, rel_tol=2e-15, abs_tol=2e-15)
    assert F(6)*F(2) == (F(6)/3)*(F(2)*3)
    record('J-C04', dict(reservoir_annual=annual, reservoir_daily=daily,
                         arithmetic='float_identity_check', rho_times_r=F(12)))

    domain = (F(0), F(1, 2))
    assert 2*domain[1] == 1 and 2*F(3, 4) > 1
    record('J-C05', dict(composite_domain=domain, counterexample=F(3, 4), image=F(3, 2)))

    c1, c2, h1, h2 = F(1, 2), F(1, 2), F(4), F(1)
    assert min(h1, h2/c1) == 2 and c1*c2 == F(1, 4)
    # Exact coefficient equalities for x'=-x, y'=-2y, z'=-4z.
    assert -2 == c1*(-2)*2 and -3*2 == c2*(-4)*3
    record('J-C06', dict(composed_horizon=min(h1,h2/c1), composed_time_scale=c1*c2))

    flow_bound = 3*F(1, 10)+F(1, 5)
    x = F(1, 4)
    r1, r2 = 2*x, F(3)
    direct = 6*x+6
    field_bound = 3*1+2*3
    assert flow_bound == F(1, 2)
    assert direct == 3*r1+2*r2 == F(15, 2)
    assert field_bound == 9 == 6*F(1, 2)+6
    record('J-C07', dict(flow_bound=flow_bound, field_residual_at_quarter=direct,
                         field_bound=field_bound))

    spec_a, impl_a = (0, 1), (-1, 2)
    valid = impl_a[0] <= spec_a[0] <= spec_a[1] <= impl_a[1] and F(1,10) <= F(1,5)
    reverse = spec_a[0] <= impl_a[0] <= impl_a[1] <= spec_a[1]
    assert valid and not reverse
    record('J-C08', dict(refines=True, reverse_refines=False))

    upper = max(F(i+1,64)*(1-F(i,64)) for i in range(64))
    peak = F(1,2)*(1-F(1,2))
    assert upper == F(33,128) <= F(13,50)
    assert peak == F(1,4) > F(6,25)
    record('J-C09', dict(interval_upper_64=upper, certified_tolerance=F(13,50),
                         witness_x=F(1,2), witness_value=peak, refuted_tolerance=F(6,25)))

    subtraction = (F(0)-F(1), F(1)-F(0))
    assert subtraction == (-1, 1)
    record('J-C10', dict(natural_interval_x_minus_x=subtraction,
                         denominator_crosses_zero=True, implication='no_finite_reciprocal_enclosure'))

    a = [[1,1], [2,2]]
    kernel = [1,-1]
    assert rank(a) == 1 and all(sum(x*y for x,y in zip(row,kernel)) == 0 for row in a)
    record('J-C11', dict(rank=1, null_vector=kernel, identifiable_sum=[1,1]))

    k,c,x0,lam = F(2),F(3),F(5),F(7)
    amplitude, derivative = c*x0, -k*c*x0
    assert -derivative/amplitude == k and (c/lam)*(lam*x0) == amplitude
    record('J-C12', dict(y0=amplitude, ydot0=derivative, identified_k=k,
                         transformed_c=c/lam, transformed_x0=lam*x0))

    assert F(2)**2 == F(-2)**2 == 4 and 2*F(2) != 0
    record('J-C13', dict(observation=4, real_fiber=[-2,2], positive_fiber=[2], local_derivative=4))

    var_x = F(1,3)-F(1,2)**2
    additive_var = var_x+4*var_x
    product_var = F(1,3)**2-F(1,4)**2
    first = F(1,4)*var_x/product_var
    total = F(1,3)*var_x/product_var
    assert additive_var == F(5,12)
    assert (var_x/additive_var, 4*var_x/additive_var) == (F(1,5),F(4,5))
    assert product_var == F(7,144) and first == F(3,7) and total == F(4,7)
    record('J-C14', dict(additive_variance=additive_var, additive_first=[F(1,5),F(4,5)],
                         product_variance=product_var, product_first=[first,first],
                         product_total=[total,total], product_interaction=1-2*first))

    q1 = weighted_q([1,2,3],list(map(F,[1,1,1])),F(1),F(1,4))
    q2 = weighted_q([1,2,3],list(map(F,[1,1,1])),F(4),F(1,4))
    q3 = weighted_q([1,2,3],list(map(F,[1,2,1])),F(1),F(2,5))
    assert (q1,q2,q3) == (F(3),None,F(2))
    assert weighted_q([1,2,3],list(map(F,[7,14,7])),F(7),F(2,5)) == q3
    record('J-C15', dict(equal_weights=q1, large_test_weight='positive_infinity', unequal_weights=q3))

    mass = cov_fixed = cov_weighted = unbounded = F(0)
    for bits in product([0,1], repeat=5):
        cal, target = bits[:4],bits[4]
        probability = F(9,10) if target else F(1,10)
        for b in cal:
            probability *= F(1,10) if b else F(9,10)
        weights = [F(9) if b else F(1,9) for b in cal]
        q = weighted_q(cal, weights, F(9) if target else F(1,9), F(1,5))
        mass += probability
        cov_fixed += probability * (target <= max(cal))
        cov_weighted += probability * (q is None or target <= q)
        unbounded += probability * (q is None)
    assert (mass,cov_fixed,cov_weighted,unbounded) == (1,F(40951,100000),1,F(89991,100000))
    record('J-C16', dict(enumerated_outcomes=32, total_probability=mass,
                         unweighted_coverage=cov_fixed, weighted_coverage=cov_weighted,
                         probability_unbounded=unbounded))

    q = weighted_q([0]*4,[F(1)]*4,F(1),F(1,5))
    assert q == 0 and not 1 <= q
    record('J-C17', dict(concept_shift_quantile=q, target_observation=1, coverage=0))

    fair = [(0,F(1,2)),(1,F(1,2))]
    observational1 = distribution(fair,lambda u:(u,u))
    observational2 = distribution(fair,lambda u:(u,u))
    do1 = distribution(fair,lambda u:1)
    do2 = distribution(fair,lambda u:u)
    assert observational1 == observational2 and tv(do1,do2) == F(1,2)
    record('J-C18', dict(observed_diagonal_probabilities=[F(1,2),F(1,2)],
                         do_x1_y1=[F(1),F(1,2)], interventional_tv=tv(do1,do2)))

    exo = [(u,F(1,4)) for u in product([0,1],repeat=2)]
    for a,b in product([0,1],repeat=2):
        micro = distribution(exo,lambda u: (a^b,a^b))
        macro = {(a^b,a^b):F(1)}
        assert micro == macro
    noop = distribution(exo,lambda u:(u[0]^u[1],u[0]^u[1]))
    assert noop == {(0,0):F(1,2),(1,1):F(1,2)}
    partial = distribution(exo,lambda u:(1^u[1],1^u[1]))
    wrong_macro = {(1,1):F(1)}
    assert tv(partial,wrong_macro) == F(1,2)
    record('J-C19',dict(exact_scoped_actions=5, declared_macro_actions=3,
                        partial_action_with_wrong_map_tv=tv(partial,wrong_macro)))

    source = [F(1,2),F(1,2)]
    target = [F(1,4),F(3,4)]
    s = [sum(source[z]*(x^z) for z in [0,1]) for x in [0,1]]
    t = [sum(target[z]*(x^z) for z in [0,1]) for x in [0,1]]
    assert s == [F(1,2),F(1,2)] and t == [F(3,4),F(1,4)]
    assert t[1]-t[0] == -F(1,2)
    record('J-C20',dict(source_do_probabilities=s,target_do_probabilities=t,target_ate=t[1]-t[0]))

    # Two source-target families: source mechanisms equal, target mechanisms differ.
    for x in [0,1]:
        source_family1 = distribution(fair, lambda u:x)
        source_family2 = distribution(fair, lambda u:x)
        assert source_family1 == source_family2
    assert observational1 == observational2
    assert do1 != do2
    record('J-C21',dict(source_experiments_agree=True,target_observations_agree=True,
                        target_do_x1_y1=[F(1),F(1,2)]))

    p = [[F(4,5),F(1,5)],[F(1,10),F(9,10)]]
    q = [[F(7,10),F(3,10)],[F(1,5),F(4,5)]]
    def evolve(matrix, initial, steps):
        v=initial
        for _ in range(steps):
            v=[sum(v[i]*matrix[i][j] for i in range(2)) for j in range(2)]
        return v
    p2,q2 = evolve(p,[F(1),F(0)],2),evolve(q,[F(1),F(0)],2)
    residual = max(sum(abs(p[i][j]-q[i][j]) for j in range(2)) for i in range(2))
    err = sum(abs(a-b) for a,b in zip(p2,q2))
    assert p2 == [F(33,50),F(17,50)] and q2 == [F(11,20),F(9,20)]
    assert residual == F(1,5) and err == F(11,50) <= 2*residual
    record('J-C22',dict(p_after_2=p2,q_after_2=q2,residual=residual,l1_error=err,
                        l1_bound=2*residual,tv_error=err/2,tv_bound=residual))

    collider = [('A','C'),('B','C'),('C','D')]
    assert dsep(collider,['A'],['B'])
    assert not dsep(collider,['A'],['B'],['C'])
    assert not dsep(collider,['A'],['B'],['D'])
    selection = [('S','Z'),('Z','Y'),('X','Y')]
    assert dsep(selection,['S'],['Y'],['X','Z'])
    assert not dsep(selection,[ 'S'],['Y'],['X'])
    record('J-C23',dict(collider_closed=True, conditioned_collider_open=True,
                        conditioned_descendant_open=True,s_admissible_z=True))


def serializable(x):
    if isinstance(x,F):
        return str(x)
    if isinstance(x,dict):
        return {k:serializable(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):
        return [serializable(v) for v in x]
    return x


if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    run()
    report={'schema_version':1,'purpose':'independent_plan_arithmetic_only',
            'scf_imported':False,'cases_passed':len(RESULTS),'cases':RESULTS}
    rendered=json.dumps(serializable(report),ensure_ascii=False,indent=2)+'\n'
    if args.output:
        args.output.write_text(rendered,encoding='utf-8')
    print(f'{len(RESULTS)}/{len(RESULTS)} independent control groups passed; no SCF implementation tested.')
