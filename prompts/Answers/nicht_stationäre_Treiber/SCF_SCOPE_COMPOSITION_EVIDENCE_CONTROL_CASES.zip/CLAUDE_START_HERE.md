# Übergabe: SCF-Ausbau J0–J12

Dieses Paket enthält einen vollständigen Implementierungsplan und eine unabhängige Kontrolle seiner konkreten Rechenwerte.

1. Lies `SCF_SCOPE_COMPOSITION_EVIDENCE_IMPLEMENTATION_PLAN.md` vollständig.
2. Lies die aktuellen Repository-Arbeitsregeln. Referenzstand des Plans ist `4a7ed38640ac7d393017eb5556291c879c3bceac`; prüfe den tatsächlichen Arbeitsstand.
3. Leite die Kontrollen J-C01 bis J-C23 unabhängig her. Führe zusätzlich die Beilage aus:

~~~bash
python verify_plan_control_cases.py --output recomputed_control_results.json
~~~

Das Skript benötigt Python ≥3.10 und ausschließlich die Standardbibliothek. Es importiert kein SCF. Erwartet sind **23/23 bestandene Kontrollgruppen**. Exakte Brüche stehen im JSON als Zeichenketten; die Reservoir-Einheitenkontrolle verwendet Gleitkommazahlen mit Toleranz.

4. Beginne mit J0: Roadmap, aktuell bestätigte Schnittstellen und eigene Kontrollfalltabelle. Danach ein Paket pro Commit mit den Gates aus `CLAUDE.md`.
5. Implementiere den Pflichtkern J0–J12. Allgemeine ODE-Zertifizierung, allgemeines ID/sID und weitere ausdrücklich optionale Forschungsarbeiten bleiben außerhalb dieses Umfangs.

## Dateien

- `SCF_SCOPE_COMPOSITION_EVIDENCE_IMPLEMENTATION_PLAN.md`: vollständiger Plan.
- `verify_plan_control_cases.py`: unabhängige mathematische Kontrollrechnung.
- `control_results.json`: tatsächlich ausgeführte Ergebnisse dieser Kontrollrechnung.
- `SHA256SUMS.txt`: Prüfsummen der Übergabedateien.

Die Beilage ist kein bereits implementierter SCF-Patch. Ein bestandener Kontrolllauf bestätigt die Planarithmetik; er ersetzt weder Produktionsprüfungen noch Repository-CI. Blockierte oder übersprungene Realdatenläufe dürfen nicht als bestanden gezählt werden.

Dokumentation: CC BY 4.0. Prüfcode: GPL-3.0-or-later, passend zum SCF-Repository.
