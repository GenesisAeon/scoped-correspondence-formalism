"""Independent regression checks at commit 2cc4b5b; repository read-only."""
from pathlib import Path
import sys,math,json
from scipy.optimize import brentq
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'repo'/'src'))
from scoped_correspondence.viability.rate_dependent_buffer import run_buffer_spike_trajectory
from scoped_correspondence.viability.multidim_tipping_maps import buffer_response_surface
from scoped_correspondence.identifiability.profile_likelihood import likelihood_interval

t0=-13.
def exact_z(t):
 return -.5*math.sqrt(math.pi)*math.exp(.25-t)*(math.erf(t-.5)-math.erf(t0-.5))
t_star=brentq(lambda t:-exact_z(t)-math.exp(-t*t),0.,2.,xtol=1e-14)
z_star=exact_z(t_star)
traj=run_buffer_spike_trajectory(1.,0.,0.,0.,1.,1.)
b=-.694753066685
cell=buffer_response_surface(1.,0.,0.,0.,b,[1.],[1.]).cells[0]
old_example=likelihood_interval([(-.5,.25),(0.,0.),(.5,.25)],1.)
# Exactly flat on the sampled region, but a bounded global threshold set.
# chi2(theta)=max(abs(theta)-1,0)^2 <= 1 iff -2 <= theta <= 2.
xs=[-1.,-.5,0.,.5,1.]
profile=[(x,max(abs(x)-1.,0.)**2) for x in xs]
plateau_result=likelihood_interval(profile,1.)
# Also an analytic polynomial with shallow curvature, no exact plateau.
quartic_result=likelihood_interval([(x,x**4) for x in [-.1,0.,.1]],1.)
out={'commit':'2cc4b5b1cd61f40b283bd8f48f9a61479990a7fc',
 'buffer_fix':{'analytic_minimum':z_star,'analytic_minimum_time':t_star,'repository_minimum':traj.z_min,'absolute_difference':abs(z_star-traj.z_min),'z_min_ode_uncertainty':traj.z_min_ode_uncertainty,'boundary':b,'outcome':cell.outcome},
 'old_quadratic_scan':old_example,
 'exact_plateau_counterexample':{'formula':'max(abs(theta)-1,0)^2','scan':profile,'true_global_interval':[-2.,2.],'api_result':plateau_result},
 'quartic_counterexample':{'formula':'theta^4','scan_interval':[-.1,.1],'true_global_interval':[-1.,1.],'api_result':quartic_result}}
assert cell.outcome=='switched'
assert abs(z_star-traj.z_min)<1e-10
assert old_example['established_unbounded'] is False
assert plateau_result['established_unbounded'] is True
assert quartic_result['established_unbounded'] is True
(ROOT/'independent_results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
