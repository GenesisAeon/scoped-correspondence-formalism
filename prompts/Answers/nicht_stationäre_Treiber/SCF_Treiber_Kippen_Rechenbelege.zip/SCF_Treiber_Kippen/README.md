# Rechenbelege: nichtstationäre Treiber und Kippen

Bezugsstand: GenesisAeon/scoped-correspondence-formalism,
Commit 96567288a5ba80e410208226a8cc74d240af0a3c. Auswertung: 21.09.2026.

## Inhalt

- `independent_analysis.py`: unabhängige OLS-/Segment-/Dispersionsrechnungen,
  retrospektive NOAA-Fenstervergleiche, synthetische Mischung und Raten-Kippfall.
- `independent_results.json`: unveränderte Ausgabe dieser Rechnung.
- `source_verification.json`: Ergebnis des Quell- und Datenhashabgleichs.
- `suite_summary.json` und `logs/`: tatsächlich ausgeführte vier Repository-Suiten;
  insgesamt 24 von 24 benannten Checks bestanden.
- `SCF_Nichtstationaritaet_Vergleich.png`: wissenschaftliche Vergleichsgrafik.

Die ausführliche Einordnung steht in der separat bereitgestellten Datei
`SCF_Nichtstationaere_Treiber_und_Kippen.md`.

## Reproduktion

Den angegebenen Repository-Commit mit seinen Datendateien bereitstellen.
Python, NumPy, SciPy und Matplotlib werden benötigt. Die Rechnung importiert
keine Fit-Funktion aus SCF und verändert weder Quelldateien noch Rohdaten.

```bash
python independent_analysis.py --repo /pfad/zum/repository --out /pfad/zu/neuen_ergebnissen
```

Ausgeführt mit Python 3.12.14, NumPy 2.3.5, SciPy 1.17.0. Die Grafik
wird mit Matplotlib erzeugt. Datenhashes stehen in der JSON-Ausgabe und
werden vor der Berechnung mit dem Repository-Manifest verglichen.

## Aussagegrenzen

Die Originalpiloten wurden numerisch reproduziert. Alle zusätzlichen
Modellfenster und Rücktests sind explorativ und nach Kenntnis der
Originalergebnisse definiert. Sie sind keine neue prospektive Validierung.
Die Mischungs- und Ratenbeispiele sind synthetische Kontrollen, keine
Anpassungen an die Realdaten und kein empirischer Kipppunktnachweis.

Der unabhängige COVID-Strukturbruchscan umfasst alle 36 zulässigen
5+5-Segmentierungen. Die Repository-Schleife lässt den ersten Kandidaten
mit genau fünf Punkten links aus. Das verändert den optimalen Termin
20.02.2020 im vorliegenden Beispiel nicht.

Rohdaten und Repository-Quelldateien sind hier nicht dupliziert. Sie sind
am angegebenen Commit mit dem dokumentierten Manifest erhältlich.

COVID-Datenattribution: Data: Our World in Data / Johns Hopkins University
CSSE COVID-19 Data Repository. Lizenz: CC BY 4.0.
Temperatur: NOAA NCEI. Erdbebenkatalog: USGS ComCat.
