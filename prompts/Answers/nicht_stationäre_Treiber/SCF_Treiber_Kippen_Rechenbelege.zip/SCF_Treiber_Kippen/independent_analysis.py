"""Independent, retrospective diagnostics for SCF commit 96567288a.

Run: python independent_analysis.py --repo /path/to/repo --out /path/to/output
No fitting imports from SCF. NumPy/SciPy reproduce the elementary estimators.
All additional windows are exploratory, selected after seeing original results.
No causal or tipping inference is claimed from these time series alone.
"""
from __future__ import annotations
import argparse, csv, hashlib, json, math, platform
from pathlib import Path
from collections import Counter
import numpy as np
import scipy
from scipy.integrate import solve_ivp
from scipy.stats import chi2, poisson

p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
def rmse(y,yhat): return float(np.sqrt(np.mean((np.asarray(y)-np.asarray(yhat))**2)))
def ols(x,y): return np.linalg.lstsq(np.column_stack([np.ones(len(x)),x]),y,rcond=None)[0]
def read(name):
    with (a.repo/'data'/name).open(encoding='utf-8',newline='') as f:
        return list(csv.DictReader(line for line in f if line.strip() and not line.startswith('#')))

manifest=json.loads((a.repo/'data/real_data_manifest.json').read_text())
hashes={}
for ds in manifest['datasets']:
    actual=hashlib.sha256((a.repo/ds['file']).read_bytes()).hexdigest()
    assert actual==ds['sha256'];hashes[ds['id']]=actual

# Independent reproduction of original COVID A/B/C; split dates from repo protocol.
rows=read('owid_covid_world_daily_2020_2023.csv')
rows=[r for r in rows if r['weekly_cases'] and '2020-01-27'<=r['date']<='2020-03-25']
dates=np.array([r['date'] for r in rows]);t=np.arange(len(rows),dtype=float)
y=np.array([float(r['weekly_cases'])/7 for r in rows]);assert (y>0).all()
cal=dates<='2020-03-11';hold=~cal
short=cal&(dates>='2020-02-26')
theta_a=ols(t[cal],np.log(y[cal]));theta_b=ols(t[short],np.log(y[short]))
fits=[];n=int(cal.sum())
# Include all mathematically admissible 5+5 splits (repository omits first 5-point split).
for split in range(5,n-5+1):
    first=ols(t[:split],np.log(y[:split]));second=ols(t[split:n],np.log(y[split:n]))
    residual=np.r_[np.log(y[:split])-(first[0]+first[1]*t[:split]),np.log(y[split:n])-(second[0]+second[1]*t[split:n])]
    fits.append((float(residual@residual),split,first,second))
best=min(fits,key=lambda z:z[0]);theta_c=best[3]
predictions={name:np.exp(theta[0]+theta[1]*t[hold]) for name,theta in [('A',theta_a),('B',theta_b),('C',theta_c)]}
baseline=float(y[cal][-1]);baseline_rmse=rmse(y[hold],baseline)
covid={
    'fit_A_r':float(theta_a[1]),'fit_B_r':float(theta_b[1]),'fit_C_recent_r':float(theta_c[1]),
    'rmse':{name:rmse(y[hold],pred) for name,pred in predictions.items()},
    'baseline_rmse':baseline_rmse,'breakpoint_last_day_first_segment':str(dates[best[1]-1]),
    'candidates_in_independent_full_scan':len(fits),
    'A_rate_anchored_to_last_observation_rmse':rmse(y[hold],baseline*np.exp(theta_a[1]*(t[hold]-t[cal][-1]))),
    'holdout_endpoint_log_growth_per_day':float(np.log(y[hold][-1]/y[hold][0])/13),
    'holdout_endpoint_doubling_days':float(13*np.log(2)/np.log(y[hold][-1]/y[hold][0])),
}
assert math.isclose(covid['rmse']['A'],17428.699000980658,abs_tol=1e-6)
assert math.isclose(baseline_rmse,15932.675722164136,abs_tol=1e-6)
assert covid['breakpoint_last_day_first_segment']=='2020-02-20'

# Prespecified for this retrospective diagnostic: report every selected window.
temp=read('noaa_global_temp_anomaly_1880_2025.csv')
years=np.array([int(r['Year']) for r in temp]);temps=np.array([float(r['Departure from Average']) for r in temp])
temp_hold=years>=2000;temp_base=float(temps[years==1999][0]);noaa_windows=[];temp_preds={}
for start in [1880,1950,1970,1980]:
    mask=(years>=start)&(years<=1999);intercept,slope=ols(years[mask]-1999,temps[mask])
    pred=intercept+slope*(years[temp_hold]-1999);temp_preds[start]=pred
    noaa_windows.append({'start':start,'end':1999,'n':int(mask.sum()),'slope_c_per_year':float(slope),
                         'fitted_level_at_1999':float(intercept),'rmse_2000_2025':rmse(temps[temp_hold],pred)})
rolling=[]
for origin in range(1969,2020,5):
    test=(years>origin)&(years<=origin+5)
    record={'origin':origin,'horizon':5,'persistence_rmse':rmse(temps[test],temps[years==origin][0])}
    for name,start in [('expanding',1880),('last30',origin-29)]:
        mask=(years>=start)&(years<=origin);intercept,slope=ols(years[mask]-origin,temps[mask])
        record[name+'_rmse']=rmse(temps[test],intercept+slope*(years[test]-origin))
    rolling.append(record)
noaa={'original_rmse':noaa_windows[0]['rmse_2000_2025'],
      'baseline_rmse':rmse(temps[temp_hold],temp_base),'exploratory_windows':noaa_windows,
      'rolling_origins_5year_exploratory':rolling,
      'rolling_pooled_rmse':{name:float(np.sqrt(np.mean([r[name+'_rmse']**2 for r in rolling]))) for name in ['persistence','expanding','last30']}}
assert math.isclose(noaa['original_rmse'],.4604384541211939,abs_tol=1e-12)

# Annual counts: dispersion is distinct from mean-forecast RMSE.
quakes=read('usgs_earthquakes_m6plus_2000_2026.csv')
counts_by_year=Counter(int(r['time'][:4]) for r in quakes)
qyears=np.arange(2000,2026);counts=np.array([counts_by_year[int(z)] for z in qyears])
train=counts[:20];test=counts[20:];rate=float(train.mean());var=float(train.var(ddof=1))
fano=var/rate;dispersion=(len(train)-1)*fano
earthquakes={'annual_counts':dict(zip(map(str,qyears),map(int,counts))),
    'calibration_mean':rate,'calibration_sample_variance':var,'calibration_fano_factor':fano,
    'holdout_fano_factor':float(test.var(ddof=1)/test.mean()),
    'poisson_dispersion_statistic':dispersion,'poisson_dispersion_df':len(train)-1,
    'poisson_dispersion_chi2_upper_p_approx':float(chi2.sf(dispersion,len(train)-1)),
    'model_rmse':rmse(test,rate),'persistence_rmse':rmse(test,train[-1]),
    'plugin_poisson_95_interval':poisson.ppf([.025,.975],rate).astype(int).tolist(),
    'holdout_years_above_training_mean':[int(z) for z,c in zip(qyears[20:],test) if c>rate],
    'all_rows_reviewed':all(r['status']=='reviewed' for r in quakes),
    'p_value_scope':'Approximate diagnostic for independent equal-mean Poisson annual counts; exploratory, not a mechanism test.'}
assert math.isclose(earthquakes['model_rmse'],28.778507605503094,abs_tol=1e-12)

# Synthetic mixture: apparent acceleration with fixed component rates.
mix_t=np.linspace(0,40,401);rates=np.array([-.1,.15]);amplitudes=np.array([1000.,10.])
components=amplitudes[None,:]*np.exp(mix_t[:,None]*rates[None,:]);weights=components/components.sum(axis=1,keepdims=True)
effective=weights@rates;deriv=(weights@(rates*rates))-effective**2
assert deriv.min()>=-1e-14
assert np.max(np.abs(np.gradient(effective,mix_t)[1:-1]-deriv[1:-1]))<1e-6
mixture={'component_rates':rates.tolist(),'amplitudes':amplitudes.tolist(),
         'effective_rate_at_0':float(effective[0]),'effective_rate_at_40':float(effective[-1]),
         'analytic_derivative':'r_eff_dot = sum_i w_i*r_i^2 - (sum_i w_i*r_i)^2 >= 0',
         'scope':'positive exponential components with fixed rates and amplitudes; illustration, not a fit to COVID'}

# Synthetic rate-induced tipping with the same endpoints and frozen equilibria.
# xdot=(x-lambda)-(x-lambda)^3, lambda=1+tanh(r*t).
tipping=[];tip_curves=[]
for r in [.1,2.]:
    t0=-10/r;t1=10/r+20
    driver=lambda t:1+np.tanh(r*t)
    def integrate(rtol,atol,max_step):
        return solve_ivp(lambda t,x:[(x[0]-driver(t))-(x[0]-driver(t))**3],(t0,t1),[driver(t0)+1],
                         rtol=rtol,atol=atol,dense_output=True,max_step=max_step)
    sol=integrate(1e-9,1e-11,.1);fine=integrate(1e-11,1e-13,.05)
    assert sol.success and fine.success
    grid=np.linspace(t0,t1,3001);z=sol.sol(grid)[0]-driver(grid)
    max_diff=float(np.max(np.abs(sol.sol(grid)-fine.sol(grid))))
    assert max_diff<1e-6
    expected=1 if r==.1 else -1
    assert abs(z[-1]-expected)<1e-6
    tipping.append({'rate':r,'final_x':float(sol.y[0,-1]),'final_relative_z':float(z[-1]),
                    'switched_attractor':bool(z[-1]<0),'refinement_max_difference':max_diff,
                    'frozen_stable_eigenvalue':-2.,'frozen_stability_does_not_change':True})
    tip_curves.append((r,driver(grid),z))

out={'commit':'96567288a5ba80e410208226a8cc74d240af0a3c','date':'2026-09-21',
     'environment':{'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__},
     'dataset_sha256':hashes,'covid':covid,'noaa':noaa,'earthquakes':earthquakes,
     'synthetic_mixture':mixture,'synthetic_rate_tipping':tipping,
     'status':'Retrospective diagnosis. Additional comparisons were designed after original results were known. No fresh empirical validation or identified physical driver.'}
(a.out/'independent_results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
fig,axes=plt.subplots(3,1,figsize=(11,13),layout='constrained')
ax=axes[0]
ax.plot(dates.astype('datetime64[D]'),y,color='#172b4d',lw=2,label='Gemeldete Fälle: 7-Tage-Mittel')
for name,color in [('A','#cc6e30'),('B','#008375'),('C','#8356a6')]:
    ax.plot(dates[hold].astype('datetime64[D]'),predictions[name],ls='--',lw=2,color=color,label=f'Exponentialmodell {name}')
ax.axvline(np.datetime64('2020-03-11'),color='#777777',lw=1,ls=':')
ax.set_yscale('log');ax.set_ylabel('Fälle / Tag · logarithmische Achse')
ax.set_title('A  COVID: Gleiche Modellfamilie, verschiedene Kalibrierungsfenster',loc='left',weight='bold')
ax.legend(loc='upper left',fontsize=9,ncol=2);ax.grid(alpha=.16)
ax.text(.01,.03,'A: 45 Tage | B: 15 Tage | C: zweites Segment nach erkanntem Bruch\nStrichlinien: unveränderter Testzeitraum 12.–25. März 2020',transform=ax.transAxes,fontsize=9)

ax=axes[1];mask=years>=1950
ax.plot(years[mask],temps[mask],color='#172b4d',lw=1.7,label='NOAA-Jahresanomalie')
for start,color in [(1880,'#cc6e30'),(1970,'#008375')]:
    ax.plot(years[temp_hold],temp_preds[start],lw=2,ls='--',color=color,label=f'Linearer Fit {start}–1999')
ax.axvline(1999,color='#777777',lw=1,ls=':');ax.set_ylabel('Temperaturanomalie [°C]')
ax.set_title('B  NOAA: Auch eine lineare Gerade kann nach Fensterwechsel deutlich besser sein',loc='left',weight='bold')
ax.legend(loc='upper left',fontsize=9);ax.grid(alpha=.16)
ax.text(.01,.03,'Basis: 1901–2000. Neuer Fenstervergleich: nachträgliche Diagnose, keine neue unabhängige Bestätigung.',transform=ax.transAxes,fontsize=8.5)

ax=axes[2]
for r,lam,z in tip_curves:
    ax.plot(lam,z,lw=2.2,label=f'Treiberänderung r = {r:g}',color='#008375' if r==.1 else '#cc6e30')
ax.axhline(0,color='#777777',ls=':',label='Instabiles Gleichgewicht bei eingefrorenem Treiber')
ax.axhline(1,color='#c2c8d0',ls='--',lw=1);ax.axhline(-1,color='#c2c8d0',ls='--',lw=1)
ax.set_ylim(-1.15,1.15);ax.set_xlim(0,2.03);ax.set_xlabel('Treiberwert λ entlang desselben Wegs von 0 nach 2')
ax.set_ylabel('Relativer Zustand z = x − λ')
ax.set_title('C  Synthetischer Kontrollfall: Gleicher Treiberweg, anderes Ergebnis durch das Tempo',loc='left',weight='bold')
ax.legend(loc='lower left',fontsize=9);ax.grid(alpha=.16)
fig.suptitle('Nichtstationarität, Modellfenster und rateninduziertes Kippen',fontsize=17,weight='bold')
fig.supxlabel('A/B: Repository 96567288a; Daten: OWID / JHU CSSE (CC BY 4.0), NOAA NCEI.\nC: eigene illustrative Simulation; kein empirischer Kipppunktnachweis. Analyse: 21.09.2026.',fontsize=9)
fig.savefig(a.out/'SCF_Nichtstationaritaet_Vergleich.png',dpi=170)
plt.close(fig)
print(json.dumps(out,ensure_ascii=False,indent=2))
