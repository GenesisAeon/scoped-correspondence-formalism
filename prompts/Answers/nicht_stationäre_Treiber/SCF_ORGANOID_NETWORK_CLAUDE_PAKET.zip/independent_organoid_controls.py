#!/usr/bin/env python3
"""Independent planning oracles. No SCF, classifier, optimiser, or real data.
SPDX-License-Identifier: GPL-3.0-or-later
Run: python independent_organoid_controls.py --output independent_organoid_results.json
"""
import argparse
from collections import defaultdict
from fractions import Fraction as F
from itertools import product
import json
import math
from pathlib import Path

CASES=[]
def close(a,b):
    assert math.isclose(a,b,rel_tol=2e-12,abs_tol=2e-13),(a,b)
def case(cid,title,values):
    CASES.append(dict(id=cid,title=title,passed=True,values=values))
def entropy(masses):
    return -sum(float(p)*math.log2(float(p)) for p in masses if p)
def marginal(p,which):
    r=defaultdict(F)
    for row,w in p.items():
        r[tuple(row[i] for i in which)]+=w
    return r

def mi(p,a,b):
    return entropy(marginal(p,a).values())+entropy(marginal(p,b).values())-entropy(marginal(p,a+b).values())
def cmi(p,a,b,c):
    return entropy(marginal(p,a+c).values())+entropy(marginal(p,b+c).values())-entropy(marginal(p,c).values())-entropy(marginal(p,a+b+c).values())
def joint_channel(q,prior=(F(1,2),F(1,2))):
    return {(s,y):prior[s]*q[s][y] for s in range(2) for y in range(2) if prior[s]*q[s][y]}
def bayes_accuracy(p):
    ys={row[1] for row in p}
    return sum(max(p.get((0,y),F(0)),p.get((1,y),F(0))) for y in ys)
def spatial(d):
    return ((1+d,1-d),(1-d,1+d))
def gaussian_accuracy(d,sigma):
    if sigma==0: return .5 if d==0 else 1.0
    return .5*(1+math.erf(abs(d)/sigma))

def normalize_rows(a,gamma):
    out=[]
    for row in a:
        s=sum(row)
        if s<=0: raise ValueError('row requires positive mass')
        out.append([gamma*v/s for v in row])
    return out

def hebb(a,pre,post,eta,gamma):
    raw=[[F(0) if i==j else (1-eta)*a[i][j]+eta*post[i]*pre[j]
          for j in range(len(a))] for i in range(len(a))]
    return normalize_rows(raw,gamma)

def topology(n,m,c,gamma):
    assert n%m==0 and n//m>=2
    size=n//m; a=[]
    for i in range(n):
        row=[]
        for j in range(n):
            if i==j: v=F(0)
            elif m==1: v=gamma/F(n-1)
            elif i//size==j//size: v=gamma*(1-c)/F(size-1)
            else: v=gamma*c/F(n-size)
            row.append(v)
        a.append(row)
    return a

# ON-C01: deterministic response columns and constant aggregate resource.
for d in (F(0),F(1,2),F(1)):
    y1,y2=spatial(d)
    assert sum(y1)==sum(y2)==2
    assert y1[0]*y2[1]-y2[0]*y1[1]==4*d
assert spatial(F(1,2))==((F(3,2),F(1,2)),(F(1,2),F(3,2)))
case('ON-C01','spatial coding at constant aggregate response',{'delta_half_outputs':[['3/2','1/2'],['1/2','3/2']],'column_sum':2,'determinant_formula':'4*delta'})

# ON-C02: finite noiseless fibers, not a continuous/noisy inference claim.
y=spatial(F(1,2)); full={s:y[s] for s in (0,1)}; summed={s:sum(y[s]) for s in (0,1)}
assert len({v for v in full.values()})==2 and len(set(summed.values()))==1
p_full={(0,full[0]):F(1,2),(1,full[1]):F(1,2)}
p_sum={(0,2):F(1,2),(1,2):F(1,2)}
close(mi(p_full,(0,),(1,)),1);close(mi(p_sum,(0,),(1,)),0)
case('ON-C02','observer determines retained distinctions',{'I_full_bits':1,'I_sum_bits':0,'sum_fiber':[0,1]})

# ON-C03: invertible output relabelling preserves information.
p={(0,(F(3,2),F(1,2))):F(1,2),(1,(F(1,2),F(3,2))):F(1,2)}
p_swap={(s,(y[1],y[0])):w for (s,y),w in p.items()}
close(mi(p,(0,),(1,)),mi(p_swap,(0,),(1,)))
case('ON-C03','invertible sensor permutation preserves information',{'I_before_bits':1,'I_after_bits':1})

# ON-C04: spherical additive Gaussian noise; equal priors and Bayes readout.
acc=gaussian_accuracy(.5,.5)
close(acc,0.9213503964748575)
assert gaussian_accuracy(0,.5)==.5 and gaussian_accuracy(.5,0)==1
case('ON-C04','analytic Gaussian classification control',{'delta':.5,'sigma':.5,'bayes_accuracy':acc,'formula':'0.5*(1+erf(abs(delta)/sigma))'})

# ON-C05: a completely flipped channel still has one bit of information.
rows=[]
for e in [F(0),F(1,10),F(1,4),F(1,2),F(1)]:
    q=((1-e,e),(e,1-e));p=joint_channel(q)
    info=mi(p,(0,),(1,)); target=1-entropy([e,1-e])
    close(info,target); assert bayes_accuracy(p)==max(e,1-e)
    rows.append(dict(epsilon=str(e),information_bits=info,naive_accuracy=float(1-e),optimal_accuracy=float(bayes_accuracy(p))))
case('ON-C05','binary channel accuracy versus information',{'channels':rows})

# ON-C06: identical accuracy does not determine mutual information or capacity.
bsc=((F(3,4),F(1,4)),(F(1,4),F(3,4)))
z=((F(1),F(0)),(F(1,2),F(1,2)))
pb,pz=joint_channel(bsc),joint_channel(z)
assert bayes_accuracy(pb)==bayes_accuracy(pz)==F(3,4)
ib,iz=mi(pb,(0,),(1,)),mi(pz,(0,),(1,))
close(ib,.18872187554086717);close(iz,.31127812445913283)
pzopt=joint_channel(z,(F(3,5),F(2,5)))
close(mi(pzopt,(0,),(1,)),math.log2(1.25))
case('ON-C06','same accuracy; different information',{'accuracy':.75,'I_bsc_bits':ib,'I_z_bits':iz,'C_z_bits':math.log2(1.25),'z_optimal_prior':[.6,.4]})

# ON-C07: data processing, Y=(S,N) and Z=N.
p={(s,(s,n),n):F(1,4) for s,n in product((0,1),repeat=2)}
close(mi(p,(0,),(1,)),1);close(mi(p,(0,),(2,)),0)
case('ON-C07','discarding features can remove all target information',{'I_S_Y':1,'I_S_Z':0})

# ON-C08: hidden state changes coding; snapshot capacities cannot be pooled blindly.
p={(s,s^h,h):F(1,4) for s,h in product((0,1),repeat=2)}
close(mi(p,(0,),(1,)),0);close(cmi(p,(0,),(1,),(2,)),1)
case('ON-C08','unknown channel state hides an otherwise invertible code',{'I_S_Y':0,'I_S_Y_given_H':1})

# ON-C09: an old readout can fail despite unchanged information.
before={(s,s):F(1,2) for s in (0,1)}; after={(s,1-s):F(1,2) for s in (0,1)}
frozen=sum(w for (s,y),w in after.items() if s==y)
assert frozen==0 and bayes_accuracy(after)==1
close(mi(before,(0,),(1,)),mi(after,(0,),(1,)))
case('ON-C09','frozen versus adapted decoder',{'frozen_accuracy_after':0,'refitted_optimal_accuracy_after':1,'information_bits_before_and_after':1})

# ON-C10: prior imbalance creates high raw accuracy with zero information.
p=joint_channel(((F(1),F(0)),(F(1),F(0))),(F(9,10),F(1,10)))
assert bayes_accuracy(p)==F(9,10);close(mi(p,(0,),(1,)),0)
case('ON-C10','class imbalance is not information gain',{'accuracy':.9,'balanced_accuracy':.5,'information_bits':0})

# ON-C11: exact bounded Hebbian weight update, not a biological mechanism claim.
gamma=F(1,2);a=[[F(0),gamma,F(0)],[F(1,4),F(0),F(1,4)],[F(0),gamma,F(0)]]
updated=hebb(a,[F(1),F(0),F(0)],[F(0),F(1),F(0)],F(1,2),gamma)
assert updated[1]==[F(5,12),F(0),F(1,12)]
assert all(sum(row)==gamma for row in updated)
case('ON-C11','row-normalized unsupervised lagged update',{'updated_second_row':['5/12','0','1/12'],'every_row_sum':'1/2'})

# ON-C12: frozen plasticity and deterministic contraction bound.
assert hebb(a,[F(1),F(0),F(0)],[F(0),F(1),F(0)],F(0),gamma)==a
leak=F(1,2);q=1-leak+leak*gamma
assert q==F(3,4) and q<1
case('ON-C12','zero learning rate and contraction certificate',{'eta_zero_identity':True,'lipschitz_bound':'3/4','scope':'fixed A, same input, tanh is 1-Lipschitz'})

# ON-C13: XOR has full information, but a single affine threshold is insufficient.
p={(s,a,b):F(1,4) for a,b in product((0,1),repeat=2) for s in [a^b]}
close(mi(p,(0,),(1,2)),1)
# Enumerate integer affine thresholds sufficient to realize all separable binary-vertex labelings.
best=F(0)
for w1,w2,bias in product(range(-3,4),repeat=3):
    score=sum(w for (s,a,b),w in p.items() if int(w1*a+w2*b+bias>=0)==s)
    best=max(best,score)
assert best==F(3,4)
case('ON-C13','decoder class can limit observed performance',{'best_affine_accuracy_on_four_vertices':.75,'XOR_decoder_accuracy':1,'information_bits':1,'proof_note':'XOR opposite corners cannot be strictly separated by one affine line; enumeration is a finite corroboration'})

# ON-C14: analytic PID expectations; independent script does not run a PID solver.
xor={(a,b,a^b):F(1,4) for a,b in product((0,1),repeat=2)}
red={(s,s,s):F(1,2) for s in (0,1)}
assert all(abs(mi(xor,(i,),(2,)))<1e-12 for i in (0,1))
close(mi(xor,(0,1),(2,)),1)
for axes in [(0,),(1,),(0,1)]: close(mi(red,axes,(2,)),1)
case('ON-C14','exact XOR and redundancy distributions',{'XOR_MI_signature':[0,0,1],'redundancy_MI_signature':[1,1,1],'expected_BROJA_XOR_synergy':1,'expected_BROJA_redundancy':1,'PID_solver_executed':False})

# ON-C15: positive directed information under a common cause, no A->B structural edge.
# Row coordinates (A1,A2,B1,B2,U); A=(U,0), B=(0,U).
p={(u,0,0,u,u):F(1,2) for u in (0,1)}
di=mi(p,(0,),(2,))+cmi(p,(0,1),(3,),(2,))
conditional= cmi(p,(0,),(2,),(4,))+cmi(p,(0,1),(3,),(2,4))
close(di,1);close(conditional,0)
# Intervening on A1 leaves U and B2=U untouched.
def interventional_b(forced_a1):
    result=defaultdict(F)
    for u in (0,1):
        a1=forced_a1  # replacement of A1=U; B2 still follows its own equation.
        b2=u
        result[(a1,b2)]+=F(1,2)
    return sum(w for (a,b),w in result.items() if b==1)
assert interventional_b(0)==interventional_b(1)==F(1,2)
case('ON-C15','directed information does not identify a direct causal edge',{'I_A_to_B_bits':di,'I_A_to_B_conditioned_on_U_bits':conditional,'P_B2_equals_1_do_A1_0':.5,'P_B2_equals_1_do_A1_1':.5})

# ON-C16: block order can perfectly predict labels without a stimulus response.
blocked={(t,t,t):F(1,2) for t in (0,1)} # S=time, Y=time
randomized={(s,t,t):F(1,4) for s,t in product((0,1),repeat=2)}
close(mi(blocked,(0,),(1,)),1);close(mi(randomized,(0,),(1,)),0)
case('ON-C16','block drift masquerading as decoding',{'blocked_I_bits':1,'randomized_I_bits':0})

# ON-C17: duplicating trials does not create new preparations.
means=[F(i) for i in range(1,6)]
replicated=[[x]*100 for x in means]
assert [sum(r)/len(r) for r in replicated]==means
avg=sum(means)/len(means);ss=sum((x-avg)**2 for x in means)
cluster_sem2=ss/F(4)/5
flat=[x for r in replicated for x in r]
flatavg=sum(flat)/len(flat);naive_sem2=sum((x-flatavg)**2 for x in flat)/F(499)/500
assert cluster_sem2==F(1,2) and naive_sem2==F(2,499)
case('ON-C17','pseudoreplication control',{'n_preparations':5,'n_duplicated_trials':500,'cluster_sem_squared':str(cluster_sem2),'naive_sem_squared':str(naive_sem2)})

# ON-C18: exact two-sided sign flip; sign-exchangeability assumed.
d=[F(i) for i in range(1,6)];obs=abs(sum(d));stats=[abs(sum(s*x for s,x in zip(signs,d))) for signs in product((-1,1),repeat=5)]
pvalue=F(sum(t>=obs for t in stats),len(stats))
assert pvalue==F(1,16)
case('ON-C18','small-sample exact paired test resolution',{'permutations':32,'two_sided_p':'1/16','scope':'illustrative data and symmetric/sign-exchangeable null; not a reanalysis of the article'})

# ON-C19: compare changes directly; separate within-group significance is insufficient.
treated=[F(1,5),F(3,10)];control=[F(1,10),F(1,5)]
effect=sum(treated)/2-sum(control)/2
assert effect==F(1,10)
case('ON-C19','difference in mean changes',{'treated_change':'1/4','control_change':'3/20','between_group_difference':'1/10'})

# ON-C20: group and preprocessing leakage; only toy pipeline metadata are checked.
train_groups={'culture_A','culture_B'};test_groups={'culture_C'}
assert not (train_groups & test_groups)
assert train_groups & {'culture_B','culture_C'}
train=[F(0),F(2)];heldout=[F(100)]
train_mean=sum(train)/len(train)
assert train_mean==1 and sum(train+heldout)/3==34
case('ON-C20','split and preprocessing leakage fixtures',{'training_mean':1,'leaky_pooled_mean':34,'overlapping_group_rejected':'culture_B'})

# ON-C21: missing channel rows cannot be reconstructed from one aggregate score.
def validate(q):
    if not q or any(len(row)!=len(q[0]) for row in q): raise ValueError('shape')
    if any(not math.isfinite(float(v)) or v<0 for row in q for v in row): raise ValueError('probability')
    if any(sum(row)!=1 for row in q): raise ValueError('row sum')
    return True
assert validate(bsc)
for invalid in [((F(1),F(1)),(F(0),F(1))),((F(-1),F(2)),(F(0),F(1))),((math.nan,0),(0,1))]:
    try: validate(invalid)
    except ValueError: pass
    else: raise AssertionError('invalid channel accepted')
case('ON-C21','channel validity and missing-row discipline',{'invalid_channel_fixtures':3})

# ON-C22: matched node count and incoming total weight; topology still changes.
budgets=[]
for m in (1,2,3):
    mat=topology(12,m,F(1,4),F(4,5))
    assert len(mat)==12 and all(sum(row)==F(4,5) for row in mat)
    assert all(mat[i][i]==0 for i in range(12))
    if m>1:
        for i,row in enumerate(mat):
            inter=sum(row[j] for j in range(12) if i//(12//m)!=j//(12//m))
            assert inter==F(1,5)
    budgets.append({'modules':m,'nodes':12,'row_sum':'4/5'})
case('ON-C22','resource matching without a forced trio advantage',{'budgets':budgets,'note':'For M=1 the inter-module fraction is not applicable.'})

# ON-C23: identical operators with different module labels have identical behavior.
flat=topology(12,1,F(0),F(4,5))
assert topology(12,2,F(6,11),F(4,5))==flat
assert topology(12,3,F(8,11),F(4,5))==flat
case('ON-C23','module labels alone create no capability',{'N':12,'equivalent_c_by_M':{'1':'not_applicable','2':'6/11','3':'8/11'},'all_off_diagonal_weights':'4/55'})

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    result=dict(schema_version=1,date='2026-10-01',kind='independent_planning_controls',
        production_code_tested=False,real_data_used=False,counts={'passed':len(CASES),'failed':0},cases=CASES,
        limitations=['No adaptive-network benchmark executed.','No SCF production code imported.',
        'No biological or clinical result reproduced.','PID atoms are analytic expectations; production solver not run.',
        'No hypothesis about a universal three-module threshold tested.'])
    if args.output:args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(f'{len(CASES)}/{len(CASES)} independent control groups passed')
