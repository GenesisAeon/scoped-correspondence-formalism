# Übergabe an Claude-Code: SCF-Organoid-Anschluss

Stand: 01.10.2026.

## Hauptauftrag

Lies `SCF_ORGANOID_NETWORK_IMPLEMENTATION_PLAN.md` vollständig und setze den dort beschriebenen synthetischen und mathematischen Kern ON0–ON7 im aktuellen SCF-Repo um. ON6b ist ein optionaler Realdatenzweig mit eigenen Daten-Gates. Keine Daten erfinden und fehlende Rohdaten nicht durch aggregierte Accuracy-Werte ersetzen.

Der Plan umfasst acht Pakete, konkrete vorhandene APIs, eigene Modellgleichungen, ein Vergleichsprotokoll, Quellen, 23 Kontrollgruppen und Abnahmekriterien. Die geprüfte Repo-Basis war `4a7ed38640ac7d393017eb5556291c879c3bceac`; aktuellen Stand und Anweisungen vor Beginn erneut prüfen.

## Inhalt dieses Pakets

- `SCF_ORGANOID_NETWORK_IMPLEMENTATION_PLAN.md`: selbsttragender Implementierungsplan.
- `independent_organoid_controls.py`: unabhängige Referenzrechnungen, ausschließlich Python-Standardbibliothek.
- `independent_organoid_results.json`: ausgeführte Ergebnisse, 23/23 Kontrollgruppen bestanden.
- `README_CLAUDE.md`: diese Startanleitung.
- `SHA256SUMS`: Prüfsummen der vier vorstehenden Dateien, ohne Selbstreferenz.

```bash
python independent_organoid_controls.py --output independent_organoid_results.json
```

Die Referenzrechnungen importieren keinen SCF-Code und führen weder einen biologischen Datenfit noch den adaptiven Benchmark aus. Die PID-Werte sind analytische Erwartungen; der bestehende BROJA-Solver muss in der Produktionsprüfung tatsächlich aufgerufen werden.

## Entscheidende Trennungen

1. Netzwerkzustand, veränderliche Kopplung, Messoperator und Decoder sind verschiedene Komponenten.
2. Ein höherer Decoder-Score bedeutet nicht automatisch zusätzliche Information; ein schlechterer eingefrorener Decoder nicht automatisch Informationsverlust.
3. Modulzahl, Eingangsarchitektur, Zustandszahl und Beobachtungsbudget werden separat geführt.
4. Gerichtete statistische Information beweist keine direkte kausale Verbindung.
5. Biologische Präparate, Simulationsläufe und wiederholte Reize dürfen statistisch nicht gleichgesetzt werden.
6. Identische Operatoren unter anderen Modulnamen müssen identisches Verhalten liefern; kein Trio-Vorteil wird vorausgesetzt.

Herleitungen zuerst unabhängig nachvollziehen. Danach eigene Produktionsprüfungen gegen die Kontrollen schreiben, nicht denselben Code auf beiden Seiten verwenden. Paketweise Regression, explizite Testkategorien und Commit-/Push-Ablauf richten sich nach dem aktuellen `CLAUDE.md` und dem Arbeitsauftrag.

Dokumentation: CC BY 4.0. Kontrollcode: GPL-3.0-or-later. Keine Fremddaten oder Abbildungen aus den Originalarbeiten sind im Paket enthalten.
