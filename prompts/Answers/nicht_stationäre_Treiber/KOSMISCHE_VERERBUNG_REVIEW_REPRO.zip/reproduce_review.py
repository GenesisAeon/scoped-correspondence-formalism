"""Read-only, targeted reproduction of the cosmic inheritance review.

Usage: python reproduce_review.py --feldtheorie /path/Feldtheorie
       --type6repo /path/implosive-origin-utac --output findings.json

Requires numpy and matplotlib. Uses the real source modules without changes.
No renderer loop or child universe process is started. These checks confirm
findings on the reviewed revisions; they are not a green release gate.
"""
from __future__ import annotations

import argparse
import contextlib
import copy
import importlib
import importlib.util
import json
import math
import os
from pathlib import Path
import platform
import random
import sys
import tempfile
import types


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


@contextlib.contextmanager
def cwd(path):
    old = Path.cwd()
    os.chdir(path)
    try:
        yield
    finally:
        os.chdir(old)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--feldtheorie', type=Path, required=True)
    parser.add_argument('--type6repo', type=Path, required=True)
    parser.add_argument('--output', type=Path, default=Path('findings.json'))
    args = parser.parse_args()
    feld = args.feldtheorie.resolve()
    other = args.type6repo.resolve()
    sys.path.insert(0, str(feld))
    os.environ['MPLBACKEND'] = 'Agg'
    # Isolate the reviewed subpackage from unrelated eager imports in the
    # repository-wide simulation/__init__.py. This is a module-level audit,
    # not a smoke test of the top-level package or its full dependencies.
    namespace = types.ModuleType('simulation')
    namespace.__path__ = [str(feld / 'simulation')]
    namespace.__package__ = 'simulation'
    sys.modules['simulation'] = namespace
    import numpy as np
    from simulation.v4_stellar_forge.universe_dna import UniverseDNA
    from simulation.v4_stellar_forge.physics_engine import PhysicsEngine, AtomAgent, ElementTypes
    from simulation.v4_stellar_forge.big_bang_renderer import initialize_bang
    from simulation.v4_stellar_forge.multiverse_manager import MultiverseManager

    result = {'python': platform.python_version(), 'numpy': np.__version__,
              'scope': 'isolated real subpackage modules; simulation root initializer bypassed', 'checks': {}}
    checks = result['checks']

    # These five test functions have no pytest fixtures; execute their exact
    # bodies directly, without claiming a complete pytest/package run.
    tests = load_module('review_existing_dna_tests', feld / 'tests/test_universe_dna.py')
    names = sorted(n for n in vars(tests) if n.startswith('test_') and callable(getattr(tests, n)))
    for name in names:
        getattr(tests, name)()
    checks['existing_dna_test_functions'] = {'passed': len(names), 'names': names, 'runner': 'direct function calls'}

    # Real signal-writing path, confined to temporary directories.
    counts = {}
    with tempfile.TemporaryDirectory(prefix='cosmic-review-') as temp:
        for case, agents in (
            ('no_black_hole', [AtomAgent(-1, 0, 0, 0, ElementTypes.HYDROGEN)]),
            ('one_black_hole', [AtomAgent(0, 0, 0, 0, ElementTypes.BLACK_HOLE, 25)]),
            ('two_black_holes', [AtomAgent(0, 0, 0, 0, ElementTypes.BLACK_HOLE, 25),
                                  AtomAgent(1, 0, 0, 0, ElementTypes.BLACK_HOLE, 30)]),
        ):
            directory = Path(temp) / case
            directory.mkdir()
            with cwd(directory):
                engine = PhysicsEngine(UniverseDNA(), case, 0)
                engine.fusion_step(agents)
                engine.fusion_step(agents)
                counts[case] = len(list(Path('output/signals').glob('*.json')))
    assert counts == {'no_black_hole': 0, 'one_black_hole': 1, 'two_black_holes': 1}
    random.seed(71)
    initial = initialize_bang(UniverseDNA())
    seeded = [a.mass for a in initial if a.type == ElementTypes.BLACK_HOLE]
    assert seeded == [25.0]
    checks['seeded_single_reproduction'] = {'signals_after_two_steps': counts, 'initial_black_hole_masses': seeded}

    def pair():
        return [AtomAgent(-1, 0, 0, 0, ElementTypes.HYDROGEN), AtomAgent(1, 0, 0, 0, ElementTypes.HYDROGEN)]

    def evolve(dna):
        agents = pair()
        engine = PhysicsEngine(dna, 'read_only', 0)
        for _ in range(5):
            engine.gravity_step(agents)
            engine.fusion_step(agents)
        return [(a.x, a.y, a.vx, a.vy, a.mass, a.type.value) for a in agents]

    ordinary = evolve(UniverseDNA())
    unused = evolve(UniverseDNA(fusion_threshold=20, entropy_rate=0.7))
    active = evolve(UniverseDNA(gravity_const=0.10))
    assert ordinary == unused and ordinary != active
    checks['inactive_dna_parameters'] = {'fusion_entropy_change_bit_identical': ordinary == unused,
                                         'gravity_positive_control_differs': ordinary != active}

    normal = pair()
    reverse = copy.deepcopy(normal)
    reverse.reverse()
    PhysicsEngine(UniverseDNA(), 'a', 0).gravity_step(normal)
    PhysicsEngine(UniverseDNA(), 'b', 0).gravity_step(reverse)
    reverse.reverse()
    p_normal = sum(a.mass * a.vx for a in normal)
    p_reverse = sum(a.mass * a.vx for a in reverse)
    max_change = max(abs(a.x - b.x) for a, b in zip(normal, reverse))
    assert abs(p_normal) > 1e-5 and math.isclose(p_normal, -p_reverse, abs_tol=1e-15)
    assert max_change > 1e-5
    checks['gravity_iteration_order'] = {'momentum_initial': 0, 'momentum_after_normal': p_normal,
                                         'momentum_after_reversed': p_reverse, 'max_position_difference': max_change}

    try:
        importlib.import_module('simulation.v4_stellar_forge.cosmic_cycle_demo')
    except ImportError as error:
        assert 'accretion_step' in str(error), str(error)
        checks['cosmic_cycle_import'] = {'error': str(error)}
    else:
        raise AssertionError('Expected import incompatibility was not reproduced')
    assert not hasattr(MultiverseManager, 'terminate_all')
    checks['manager_shutdown_contract'] = {'terminate_all_present': False}

    type6 = load_module('review_type6_ode', other / 'src/implosive_origin/type6_ode.py')
    ode = type6.Type6ODE()
    claimed = ode.fixed_point()
    true = ode.p.K_min
    residual = ode.dHdt(claimed)
    assert residual > 1e-5 and ode.dHdt(true) == 0.0
    final = ode.integrate(H0=1, t_max=1000, n_steps=10000)[-1]
    exact = true + (1 - true) * math.exp(-ode.p.r * math.tanh(ode.p.sigma * ode.p.gamma) * final.t)
    assert abs(final.H - true) < 1e-7 and not final.at_fixed_point
    checks['type6_fixed_point'] = {'claimed_fixed_point': claimed, 'true_positive_fixed_point': true,
                                  'derivative_at_claimed': residual, 'derivative_at_true': ode.dHdt(true),
                                  'H_at_1000': final.H, 'analytic_H_at_1000': exact,
                                  'at_fixed_point_flag_at_1000': final.at_fixed_point}

    # Hand-solvable proposed oracles, explicitly not existing repository APIs.
    identity = np.eye(2)
    n = np.array([1.0, 1.0])
    for _ in range(2):
        n = identity @ (np.array([1.0, 2.0]) * n)
    pi = np.array([0.25, 0.75])
    erased = np.outer(pi, np.ones(2)) @ (np.array([1.0, 2.0]) * np.array([0.4, 0.6]))
    erased /= erased.sum()
    assert np.array_equal(n, [1, 4]) and np.allclose(erased, pi)
    checks['proposed_operator_oracles'] = {'status': 'new mathematical controls, not implementation validation',
                                           'n_after_2': n.tolist(), 'p_after_2': (n/n.sum()).tolist(),
                                           'parent_erasure_distribution': erased.tolist()}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()
