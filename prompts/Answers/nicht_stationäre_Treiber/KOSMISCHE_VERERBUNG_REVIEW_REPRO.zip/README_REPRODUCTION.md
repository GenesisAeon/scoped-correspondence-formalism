# Reproduktion des Reviews vom 27.09.2026

Die Beilage bestätigt einzelne Befunde auf festgelegten Quellständen. Sie ist kein allgemeiner Test-Runner und keine kosmologische Simulation. Nach Reparaturen können ihre bewusst auf das alte Verhalten gerichteten Assertions fehlschlagen.

## Dateien

- `KOSMISCHE_VERERBUNG_BESTANDSAUFNAHME_UND_PLAN.md`: Einordnung, Quellen, Befunde und Arbeitspakete V0–V7.
- `reproduce_review.py`: unabhängige, kleine Reproduktionen.
- `findings.json`: tatsächlich erzeugte Resultate.
- `source_revisions.json`: Repository- und Commitstände.
- `source_manifest.json`: lokale SHA-256-Werte der abgerufenen Textdateien; für Feldtheorie zusätzlich Git-Blob-Abgleich.

## Ausführung

Vorhandene Checkouts auf den im Manifest benannten Ständen verwenden. Die Repositories werden nicht mitgeliefert.

```bash
python reproduce_review.py \
  --feldtheorie /path/to/Feldtheorie \
  --type6repo /path/to/implosive-origin-utac \
  --output findings.json
```

Benötigt Python, NumPy und Matplotlib. Geprüft mit Python 3.12.14 und NumPy 2.3.5; Matplotlib 3.10.8 war verfügbar. Fünf fixturefreie Original-Testfunktionen werden direkt aufgerufen. Pytest war in der Prüfumgebung nicht installiert; die fehlgeschlagene Pytest-Verfügbarkeit wurde nicht als Testfehler des Repositories gewertet.

Der Runner verwendet Originalmodule, isoliert aber das Unterpaket vom übergeordneten `simulation/__init__.py`, das andere Simulationen unmittelbar importiert. Dessen vollständige Initialisierung und Abhängigkeiten werden nicht geprüft. Der Type-6-Modulimport erfolgt direkt aus seiner Originaldatei. Es werden keine Produktionsquellen verändert, keine Endlossimulationen gestartet und keine Kindprozesse erzeugt. Signaldateien entstehen nur im temporären Verzeichnis.

`proposed_operator_oracles` prüft neue mathematische Kontrollfälle des Plans. Diese Resultate sind ausdrücklich kein Nachweis, dass schon eine entsprechende Repository-API existiert.

## Reichweite

Die verwendete Quellsammlung war ein gezielter Text-Snapshot, kein vollständiger Clone. Die behaupteten Bugs wurden auf den betroffenen Originalmodulen reproduziert; allgemeine CI-Aussagen sind daraus nicht ableitbar. SCFs neuer H-Review-Fix wurde beim abschließenden Standabgleich im Diff berücksichtigt, in diesem Paket aber nicht vollständig erneut abgenommen.
